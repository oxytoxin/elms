
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `calendar_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `calendar_events` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `allDay` tinyint(1) NOT NULL DEFAULT '1',
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `classNames` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `end` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `calendar_events_user_id_foreign` (`user_id`),
  CONSTRAINT `calendar_events_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `calendar_events` WRITE;
/*!40000 ALTER TABLE `calendar_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `calendar_events` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `campuses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campuses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `campuses` WRITE;
/*!40000 ALTER TABLE `campuses` DISABLE KEYS */;
INSERT INTO `campuses` VALUES (1,'Isulan Campus','2021-01-28 20:09:42','2021-01-28 20:09:42');
/*!40000 ALTER TABLE `campuses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `colleges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `colleges` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `colleges` WRITE;
/*!40000 ALTER TABLE `colleges` DISABLE KEYS */;
INSERT INTO `colleges` VALUES (1,'College of Engineering','2021-01-28 20:09:42','2021-01-28 20:09:42'),(2,'College of Computer Studies','2021-01-28 20:09:42','2021-01-28 20:09:42'),(3,'College of Industrial Technology','2021-01-28 20:09:42','2021-01-28 20:09:42');
/*!40000 ALTER TABLE `colleges` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `course_modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_modules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned NOT NULL,
  `module_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course_modules_course_id_foreign` (`course_id`),
  KEY `course_modules_module_id_foreign` (`module_id`),
  CONSTRAINT `course_modules_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `course_modules_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `course_modules` WRITE;
/*!40000 ALTER TABLE `course_modules` DISABLE KEYS */;
/*!40000 ALTER TABLE `course_modules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `course_teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `course_teacher` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned NOT NULL,
  `teacher_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `course_teacher_course_id_foreign` (`course_id`),
  KEY `course_teacher_teacher_id_foreign` (`teacher_id`),
  CONSTRAINT `course_teacher_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `course_teacher_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `course_teacher` WRITE;
/*!40000 ALTER TABLE `course_teacher` DISABLE KEYS */;
INSERT INTO `course_teacher` VALUES (1,144,4,NULL,NULL),(2,214,4,NULL,NULL),(3,57,4,NULL,NULL);
/*!40000 ALTER TABLE `course_teacher` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `courses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `courses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `units` decimal(8,2) NOT NULL,
  `department_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `courses_department_id_foreign` (`department_id`),
  CONSTRAINT `courses_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `courses` WRITE;
/*!40000 ALTER TABLE `courses` DISABLE KEYS */;
INSERT INTO `courses` VALUES (12,'CC111','Introduction to Computing',3.00,NULL,NULL,NULL),(13,'CS101','Fundamentals of Programming',3.00,NULL,NULL,NULL),(17,'GE07','Filipino sa ibat-ibang disiplina at Komunikasyon',3.00,NULL,NULL,NULL),(29,'FIN212','Financial Management',3.00,NULL,NULL,NULL),(30,'CC114','Data Structures and Algorithm',3.00,NULL,NULL,NULL),(31,'CS112','Fundamentals of Programming',3.00,NULL,NULL,NULL),(32,'CS111','Discrete Structures 1',3.00,NULL,NULL,NULL),(33,'GE713','Kontekswalisadong Komunikasyon sa Filipino (KOMFIL)',3.00,NULL,NULL,NULL),(34,'GE701','Mathematics in the modern world',3.00,NULL,NULL,NULL),(35,'GE706','Art Appreciation',3.00,NULL,NULL,NULL),(36,'PE101','Physical Fitness and Self-Testing Activities',3.00,NULL,NULL,NULL),(37,'NSTP101','National Service Training Program 1',2.00,NULL,NULL,NULL),(38,'CS113','Intermediate Programming',3.00,NULL,NULL,NULL),(39,'CS122','Discrete Structures 2',3.00,NULL,NULL,NULL),(40,'MATH005','Analytic Geometry',3.00,NULL,NULL,NULL),(41,'GE715','Filipino sa ibat-ibang displinal (FILDIS)',3.00,NULL,NULL,NULL),(42,'GE702','Purposived Communication',3.00,NULL,NULL,NULL),(43,'GE708','Understanding the self',3.00,NULL,NULL,NULL),(44,'PE102','Rhythmic Activities',3.00,NULL,NULL,NULL),(45,'NSTP102','National Service Training Program 2',3.00,NULL,NULL,NULL),(46,'CC112','Computer Programming 1',3.00,NULL,NULL,NULL),(47,'IS111','Fundamentals of Information Systems',3.00,NULL,NULL,NULL),(48,'ACCTG111','Financial Accounting and Reporting',3.00,NULL,NULL,NULL),(49,'CC113','Computer Programming 2',3.00,NULL,NULL,NULL),(50,'IS121','IT Infrastructure and Network Technologies',3.00,NULL,NULL,NULL),(51,'IS122','Organization and Management Concepts',3.00,NULL,NULL,NULL),(52,'ACCTG 121','Basic Accounting for Partnership and Corporate Entities',3.00,NULL,NULL,NULL),(55,'OOP212','Object-Oriented Programming',3.00,NULL,NULL,NULL),(56,'CC114','Data Structures and Algorithm',3.00,NULL,NULL,NULL),(57,'AR214','Architecture and Organization',3.00,NULL,NULL,NULL),(58,'AI215','Artificial Intelligence',3.00,NULL,NULL,NULL),(59,'MATH110','Calculus',3.00,NULL,NULL,NULL),(60,'GE705','The Contemporary World',3.00,NULL,NULL,NULL),(61,'GE703','Ethics',3.00,NULL,NULL,NULL),(62,'PE103','Team Sports',2.00,NULL,NULL,NULL),(63,'AC221','Algorithms and Complexity',3.00,NULL,NULL,NULL),(64,'PL222','Programming Languages',3.00,NULL,NULL,NULL),(65,'OS223','Operating Systems',3.00,NULL,NULL,NULL),(66,'CC115','Information Management',3.00,NULL,NULL,NULL),(67,'NC225','Networks and Communication',3.00,NULL,NULL,NULL),(68,'GE709','The Life and works of Rizal',3.00,NULL,NULL,NULL),(69,'GE704','Science, Technology and Society',3.00,NULL,NULL,NULL),(70,'PE104','Recreational Activities',2.00,NULL,NULL,NULL),(71,'ALT312','Automata Theory and Formal Languages',3.00,NULL,NULL,NULL),(72,'SE314','Software Engineering 1',3.00,NULL,NULL,NULL),(73,'CC315','Applications Development and Emerging Technology',3.00,NULL,NULL,NULL),(74,'HCI316','Human Computer Interaction',3.00,NULL,NULL,NULL),(75,'CSELECT 1','System Fundamentals',3.00,NULL,NULL,NULL),(76,'DC313','Digital Design',3.00,NULL,NULL,NULL),(77,'STAT003','Statistics with Computer Application',3.00,NULL,NULL,NULL),(78,'ENG001','Advanced Technical Writing',3.00,NULL,NULL,NULL),(79,'SE324','Software Engineering 2',3.00,NULL,NULL,NULL),(80,'FTS321','Filed Trip and Seminars',3.00,NULL,NULL,NULL),(81,'RES111','Methods of Research',3.00,NULL,NULL,NULL),(82,'IAS327','Information Assurance and Security',3.00,NULL,NULL,NULL),(83,'CSELECT2','Computational Science',3.00,NULL,NULL,NULL),(84,'CSELECT3','Intelligent Systems',3.00,NULL,NULL,NULL),(85,'CS300','Practicum (162 hours)',3.00,NULL,NULL,NULL),(86,'CS400','CS Thesis Writing 1',3.00,NULL,NULL,NULL),(87,'CSELECT4','Parallel and Distributed Computing',3.00,NULL,NULL,NULL),(88,'GE711','Cultures of Mindanao',3.00,NULL,NULL,NULL),(89,'GE712','Gender and Society',3.00,NULL,NULL,NULL),(90,'GE707','Readings in Philippine History',3.00,NULL,NULL,NULL),(91,'CS450','CS Thesis Writing 2',3.00,NULL,NULL,NULL),(92,'SPI411S','Social Issues and Professional Practice',3.00,NULL,NULL,NULL),(93,'IS111','IS Fundamentals',3.00,NULL,NULL,NULL),(94,'IS112','Office Productivity',3.00,NULL,NULL,NULL),(95,'FIL111','Komunikasyon sa Akademikong Filipino',3.00,NULL,NULL,NULL),(96,'ENG111','Communication Arts',3.00,NULL,NULL,NULL),(97,'MATH111','College Algebra',3.00,NULL,NULL,NULL),(98,'HUM111','Intro. to Humanities',3.00,NULL,NULL,NULL),(99,'PSYCHO116','General Psychology',3.00,NULL,NULL,NULL),(100,'PE111','Physical Fitness',2.00,NULL,NULL,NULL),(101,'NSTP1','NSTP I',3.00,NULL,NULL,NULL),(102,'IS113','Human Computer Interaction',3.00,NULL,NULL,NULL),(103,'IS114','Programming',3.00,NULL,NULL,NULL),(104,'IS115','Ethics for IT Professionals',3.00,NULL,NULL,NULL),(105,'IS116','Fundamental of Management and Business',3.00,NULL,NULL,NULL),(106,'ENG112','Writing in the Discipline',3.00,NULL,NULL,NULL),(107,'FIL112','Pagbasa at Pagsulat Tungo sa Pananaliksik',3.00,NULL,NULL,NULL),(108,'MATH112','Plane Trigonometry',3.00,NULL,NULL,NULL),(109,'PE112','Rhythmic Activities',2.00,NULL,NULL,NULL),(110,'NSTP2','NSTP II',3.00,NULL,NULL,NULL),(111,'IS117','System Infrastructure and Integration',3.00,NULL,NULL,NULL),(112,'IS118','System Analysis and Design',3.00,NULL,NULL,NULL),(113,'IS119','Database Management Systems (DBMS)',3.00,NULL,NULL,NULL),(114,'IS120','Business Processes and Analysis of Business Performance',3.00,NULL,NULL,NULL),(115,'IS121','Discrete Structure',3.00,NULL,NULL,NULL),(116,'FIL113','Masining na Pagpapahayag',3.00,NULL,NULL,NULL),(117,'ENG113','Speech and Oral Communication',3.00,NULL,NULL,NULL),(118,'PHYS100','Applied Physics I',3.00,NULL,NULL,NULL),(119,'PE113','Team Sports',3.00,NULL,NULL,NULL),(120,'IS122','Applications Development',3.00,NULL,NULL,NULL),(121,'IS123','Web Development',3.00,NULL,NULL,NULL),(122,'IS124','Networks and Internet Technology',3.00,NULL,NULL,NULL),(123,'LIT111','Philippine Literature',3.00,NULL,NULL,NULL),(124,'ACCTG111','Basic Accounting',3.00,NULL,NULL,NULL),(125,'STAT111','Intro. to Statistics',3.00,NULL,NULL,NULL),(126,'PHYS200','Applied Physics II',3.00,NULL,NULL,NULL),(127,'PE114','Recreational Activities',2.00,NULL,NULL,NULL),(128,'IS125','Deployment Maintenance and Services',3.00,NULL,NULL,NULL),(129,'IS126','IT Project Management and Quality Assessment',3.00,NULL,NULL,NULL),(130,'IS127','Evaluation of Business Performance',3.00,NULL,NULL,NULL),(131,'ACCTG112','Accounting and Financials',3.00,NULL,NULL,NULL),(132,'ISELEC1','Elective1',3.00,NULL,NULL,NULL),(133,'FREEELEC1','Free Elective 1',3.00,NULL,NULL,NULL),(134,'ENG114','Technical Writing and Reporting',3.00,NULL,NULL,NULL),(135,'ECON111','Principles of Economics with  Taxation',3.00,NULL,NULL,NULL),(136,'IS128','Information Systems Planning',3.00,NULL,NULL,NULL),(137,'IS129','Management of Technology',3.00,NULL,NULL,NULL),(138,'ISELEC2','Elective2',3.00,NULL,NULL,NULL),(139,'ISELEC3','Elective3',3.00,NULL,NULL,NULL),(140,'FREEELEC2','Free Elective 2',3.00,NULL,NULL,NULL),(141,'RES111','IS Research Methods',3.00,NULL,NULL,NULL),(142,'SOCSCI132','Life and Works of Rizal and Other Heroes',3.00,NULL,NULL,NULL),(143,'FTS','Field Trip and Seminars',3.00,NULL,NULL,NULL),(144,'IS130','Industry Immersion',9.00,NULL,NULL,NULL),(145,'IS131','Capstone Project',3.00,NULL,NULL,NULL),(146,'ISELEC4','Elective 4',3.00,NULL,NULL,NULL),(147,'FREEELEC3','Free Elective 3',3.00,NULL,NULL,NULL),(148,'FREEELEC4','Free Elective 4',3.00,NULL,NULL,NULL),(149,'IS133','Technopreneurship',3.00,NULL,NULL,NULL),(150,'IT111','IT Fundamentals',3.00,NULL,NULL,NULL),(151,'IT101','Programming I',3.00,NULL,NULL,NULL),(152,'IT112','Office Productivity',3.00,NULL,NULL,NULL),(154,'IT114','Computer Organization',3.00,NULL,NULL,NULL),(155,'IT115','Discrete Structure',3.00,NULL,NULL,NULL),(156,'IT103','Programming III',3.00,NULL,NULL,NULL),(157,'IT102','Programming II',3.00,NULL,NULL,NULL),(158,'IT113','Ethics for IT Professionals',3.00,NULL,NULL,NULL),(159,'IT116','Database Management System I',3.00,NULL,NULL,NULL),(160,'IT120','Operating System Applications',3.00,NULL,NULL,NULL),(161,'IT118','System Analysis and Design I',3.00,NULL,NULL,NULL),(162,'IT121','Network Management',3.00,NULL,NULL,NULL),(163,'IT122','Web Development',3.00,NULL,NULL,NULL),(164,'IT117','Database Management System II',3.00,NULL,NULL,NULL),(165,'IT119','Systems Analysis and Design II',3.00,NULL,NULL,NULL),(166,'ITELEC 1','Elective1',3.00,NULL,NULL,NULL),(171,'PHILOS111','Intro. to Logic',3.00,NULL,NULL,NULL),(172,'HIST111','Phil.  History and Culture',3.00,NULL,NULL,NULL),(173,'IT123','Multimedia Systems',3.00,NULL,NULL,NULL),(174,'IT124','Software Engineering',3.00,NULL,NULL,NULL),(175,'ITELEC 2','Elective2',3.00,NULL,NULL,NULL),(179,'IT125','Technopreneurship',3.00,NULL,NULL,NULL),(181,'IT400','Internship/Practicum/OJT',3.00,NULL,NULL,NULL),(182,'ITELEC3','Elective3',3.00,NULL,NULL,NULL),(183,'ITELEC4','Elective 4',3.00,NULL,NULL,NULL),(184,'IT401','Capstone Project',3.00,NULL,NULL,NULL),(186,'SOCIO111','Society and Culture with FP',3.00,NULL,NULL,NULL),(187,'POLSCI111','Philippine Constitution and Governance',3.00,NULL,NULL,NULL),(188,'ACCTG111','Accounting 1',3.00,NULL,NULL,NULL),(189,'ACCTG121','Accounting 2',3.00,NULL,NULL,NULL),(190,'ELECT1','Elective 1 (Customer Relationship Management)',3.00,NULL,NULL,NULL),(191,'IS212','Financial Management',3.00,NULL,NULL,NULL),(192,'PE103','Recreational Activities (Individual and Dual)',2.00,NULL,NULL,NULL),(193,'PE104','Team Sports',2.00,NULL,NULL,NULL),(194,'IS221','Systems Analysis and Design',3.00,NULL,NULL,NULL),(195,'IS222','Enterprise Architecture',3.00,NULL,NULL,NULL),(196,'IS223','Business Process and Management',3.00,NULL,NULL,NULL),(197,'ELECT2','Elective 2 (Data Mining)',3.00,NULL,NULL,NULL),(198,'IS311','Evaluation of Business Performance',3.00,NULL,NULL,NULL),(199,'IS312','System Infrastructure and Integration',3.00,NULL,NULL,NULL),(200,'IS313','IS Project Management 1',3.00,NULL,NULL,NULL),(201,'IS323','Quantitative Methods',3.00,NULL,NULL,NULL),(202,'ELECT3','Elective (Supply Chain Management)',3.00,NULL,NULL,NULL),(203,'IS314','Professional Issues in Information Systems',3.00,NULL,NULL,NULL),(204,'IS321','Managment Information System',3.00,NULL,NULL,NULL),(205,'IS322','Capstone Project 1',3.00,NULL,NULL,NULL),(206,'IS324','Information Systems Policy',3.00,NULL,NULL,NULL),(207,'CC116','Application Development and Emerging Technologies',3.00,NULL,NULL,NULL),(208,'IS412','Capstone Project 2',3.00,NULL,NULL,NULL),(209,'IS421','Practicum for Information Systems (486 hours)',6.00,NULL,NULL,NULL),(210,'ELECT 4','Elective IV (Business Intelligence)',3.00,NULL,NULL,NULL),(211,'IS411','Is Strategy, Management and Acquisition',3.00,NULL,NULL,NULL),(212,'MS121','Discrete Mathematics',3.00,NULL,NULL,NULL),(213,'IM121','Fundamentals of Database Systems',3.00,NULL,NULL,NULL),(214,'PF211','Object-Oriented Programmin',3.00,NULL,NULL,NULL),(215,'PT212','Platform Technologies',3.00,NULL,NULL,NULL),(216,'WS213','Web Systems and Technologies',3.00,NULL,NULL,NULL),(217,'PF221','Event-Driven Programming',3.00,NULL,NULL,NULL),(218,'IPT225','Integrative Programming and Technologies 1',3.00,NULL,NULL,NULL),(219,'IM223','Advanced Database Systems',3.00,NULL,NULL,NULL),(220,'HCI221','Introduction to Human Computer Interaction',3.00,NULL,NULL,NULL),(221,'MS312','Quantitative Methods (including Modeling and Simulation)',3.00,NULL,NULL,NULL),(222,'IPT313','Interactive Programming and Technologies 2',3.00,NULL,NULL,NULL),(223,'IAS314','Information Assurance and Security 1',3.00,NULL,NULL,NULL),(224,'IAS322','Information Assurance and Security 2',3.00,NULL,NULL,NULL),(225,'SIA317','Systems Integration and Architecture 1',3.00,NULL,NULL,NULL),(226,'AT316','Digital Design',3.00,NULL,NULL,NULL),(227,'NET321','Networking 2',3.00,NULL,NULL,NULL),(228,'NET311','Networking 1',3.00,NULL,NULL,NULL),(229,'AT324','Embedded Systems',3.00,NULL,NULL,NULL),(230,'CAP325','Capstone Project and Research 1',3.00,NULL,NULL,NULL),(231,'SP326','Social and Professional Issues',3.00,NULL,NULL,NULL),(232,'AT327','Mobile Computing',3.00,NULL,NULL,NULL),(233,'CAP420','Capstone Project and Research 2',3.00,NULL,NULL,NULL),(234,'SA421','System Administration and Maintenance',3.00,NULL,NULL,NULL),(235,'ACCTG210','Fundamentals of Accounting',3.00,NULL,NULL,NULL),(236,'ACCTG220','Financial Management',3.00,NULL,NULL,NULL),(237,'PRACTI 101','Practicum (486 hours)',3.00,NULL,NULL,NULL),(238,'IT103','Programming 3',3.00,NULL,NULL,NULL),(239,'ENG112','Writing in Discipline',3.00,NULL,NULL,NULL),(240,'APC211','Graphics and Multimedia Systems',3.00,NULL,NULL,NULL),(241,'CS101','Programming 1',3.00,NULL,NULL,NULL),(243,'CS102','Programming II',3.00,NULL,NULL,NULL),(246,'CS112','Data Structures',3.00,NULL,NULL,NULL),(247,'CS113','Ethics for IT Professionals',3.00,NULL,NULL,NULL),(248,'CS103','Programming III',3.00,NULL,NULL,NULL),(249,'CS114','Discrete Structure',3.00,NULL,NULL,NULL),(250,'CS115','Design and Analysis of Algorithm',3.00,NULL,NULL,NULL),(251,'MATH113','Analytic Geometry',3.00,NULL,NULL,NULL),(252,'CS104','Programmin IV',3.00,NULL,NULL,NULL),(253,'CS116','Database Systems',3.00,NULL,NULL,NULL),(254,'CS117','Programming Languages',3.00,NULL,NULL,NULL),(255,'CS118','Digital Design',3.00,NULL,NULL,NULL),(256,'CS111','CS Fundamentals',3.00,NULL,NULL,NULL),(257,'PHYS1','General Physics I',3.00,NULL,NULL,NULL),(258,'PHYS2','General Physics 2',3.00,NULL,NULL,NULL),(260,'MATH114','Calculus',3.00,NULL,NULL,NULL),(261,'CS119','Computer Organization and Assembly Lab',3.00,NULL,NULL,NULL),(262,'CS120','Automata and Language Theory',3.00,NULL,NULL,NULL),(263,'CS121','Modeling and Simulation',3.00,NULL,NULL,NULL),(266,'ENG114','Technical Writing and Reporting',3.00,NULL,NULL,NULL),(267,'HUM111','Introduction to Humanities',3.00,NULL,NULL,NULL),(268,'MATH115','Probability and Statistics',3.00,NULL,NULL,NULL),(269,'CS123','System Analysis and Design',3.00,NULL,NULL,NULL),(270,'CS124','Operating System',3.00,NULL,NULL,NULL),(272,'CSELECT2','CS Elect 2',3.00,NULL,NULL,NULL),(273,'FREEELEC1','Free Elective 1',3.00,NULL,NULL,NULL),(274,'HIST111','Phil. History and Culture',3.00,NULL,NULL,NULL),(276,'RES111','CS Research Methods',3.00,NULL,NULL,NULL),(278,'CS300','Internship/Practicum/OJT',3.00,NULL,NULL,NULL),(279,'CS132','Networking Principles',3.00,NULL,NULL,NULL),(281,'CS400','Thesis 1',3.00,NULL,NULL,NULL),(282,'CSELECT3','CS Elective 3',3.00,NULL,NULL,NULL),(283,'POLSCI111','Philippine Constitution and Governance',3.00,NULL,NULL,NULL),(284,'CS450','Thesis II',3.00,NULL,NULL,NULL),(285,'CSELECT4','CS Elective 4',3.00,NULL,NULL,NULL),(287,'CS122','Web Programming',3.00,NULL,NULL,NULL),(288,'CSELECT1','CS Elective 1',3.00,NULL,NULL,NULL),(289,'CS300','Practicum (162 hours)',3.00,NULL,NULL,NULL),(290,'CS451','Artificial Intelligence',3.00,NULL,NULL,NULL);
/*!40000 ALTER TABLE `courses` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `deans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deans` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `college_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `deans_user_id_foreign` (`user_id`),
  KEY `deans_college_id_foreign` (`college_id`),
  CONSTRAINT `deans_college_id_foreign` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`id`),
  CONSTRAINT `deans_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `deans` WRITE;
/*!40000 ALTER TABLE `deans` DISABLE KEYS */;
INSERT INTO `deans` VALUES (1,1,2,'2021-01-28 20:09:43','2021-01-28 20:09:43');
/*!40000 ALTER TABLE `deans` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `college_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `departments_college_id_foreign` (`college_id`),
  CONSTRAINT `departments_college_id_foreign` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'Bachelor of Science in Civil Engineering (BSCE)',1,'2021-01-28 20:09:42','2021-01-28 20:09:42'),(2,'Bachelor of Science in Computer Engineering (BSCpE)',1,'2021-01-28 20:09:42','2021-01-28 20:09:42'),(3,'Bachelor of Science in Electronics Engineering (BSECE)',1,'2021-01-28 20:09:42','2021-01-28 20:09:42'),(4,'Bachelor of Science in Computer Science (BSCS)',2,'2021-01-28 20:09:42','2021-01-28 20:09:42'),(5,'Bachelor of Science in Information Technology (BSIT)',2,'2021-01-28 20:09:42','2021-01-28 20:09:42'),(6,'Bachelor of Science in Information Systems (BSIS)',2,'2021-01-28 20:09:42','2021-01-28 20:09:42'),(7,'Bachelor in Technical-Vocational Teacher Education (BTVTEd) - Food Service Management',3,'2021-01-28 20:09:42','2021-01-28 20:09:42'),(8,'Bachelor in Technical-Vocational Teacher Education (BTVTEd) - Drafting Technology',3,'2021-01-28 20:09:42','2021-01-28 20:09:42'),(9,'Bachelor in Technical-Vocational Teacher Education (BTVTEd) - Automotive Technology',3,'2021-01-28 20:09:42','2021-01-28 20:09:42'),(10,'Bachelor in Technical-Vocational Teacher Education (BTVTEd) - Electrical Technology',3,'2021-01-28 20:09:42','2021-01-28 20:09:42'),(11,'Bachelor in Technical-Vocational Teacher Education (BTVTEd) - Electronic Technology',3,'2021-01-28 20:09:42','2021-01-28 20:09:42'),(12,'Bachelor in Technical-Vocational Teacher Education (BTVTEd) - Civil Technology',3,'2021-01-28 20:09:42','2021-01-28 20:09:42');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `extensions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extensions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `task_id` bigint unsigned NOT NULL,
  `student_id` bigint unsigned NOT NULL,
  `deadline` datetime NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `extensions_task_id_foreign` (`task_id`),
  KEY `extensions_student_id_foreign` (`student_id`),
  CONSTRAINT `extensions_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  CONSTRAINT `extensions_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `extensions` WRITE;
/*!40000 ALTER TABLE `extensions` DISABLE KEYS */;
/*!40000 ALTER TABLE `extensions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `files`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `files` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `fileable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fileable_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `google_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `files` WRITE;
/*!40000 ALTER TABLE `files` DISABLE KEYS */;
INSERT INTO `files` VALUES (1,'App\\Models\\Module','1','10fhqHW6SI8Q6Jeq42y_e5Qj04-218PvS','qMpBEYRJzY4UI8cLC4mCogrwQc0D7gRT33nCt1Jr.txt','GAFHqLBlpGSiIpWjkBJ63GoWJFZld5bfd9tGxTHw.txt','2021-01-28 20:17:37','2021-01-28 20:17:37'),(2,'App\\Models\\Module','1','1AZvS2hRr7PRvnUUSt-yzrlPWDCqcdcFi','home.html','A8Iiqw83MQaBwyINXQvLvkBwpDkl42C54tf10dfc.html','2021-01-28 20:17:41','2021-01-28 20:17:41'),(3,'App\\Models\\Resource','1','1N0YxRTVPncdxdF6L2TzqQ8rQIw05vjCW','Final (1).pptx','4Oxu0bR7Iv1FgWRcr22aAKuvpsEaFae8tFOWwqrV.pptx','2021-01-28 20:55:49','2021-01-28 20:55:49'),(4,'App\\Models\\Resource','2','1nDXi10N_JftAg_DT10kvRe8Ia9J4AQjK','Final (1).pptx','XSposjI070RqSGu9dUnatAeLzhskZTsuzvTMZ9pu.pptx','2021-01-28 21:12:53','2021-01-28 21:12:53'),(5,'App\\Models\\Resource','2','1e8g_hrm86CDfO47LTUm6op0bkGpo6MFL','home.html','Cszp59ZahiiqXFGh11ZbFcmDza2XJTIxXPJQbsEV.html','2021-01-28 21:12:57','2021-01-28 21:12:57'),(6,'App\\Models\\Resource','2','1Tq349QCQJrBZc1K_2AoV8lEg77noJ9Cq','Conference-template-A4-1.doc','l7uz5KmjBVZDnc2oMjHX67iqm6G6wkj9eNf6EDLm.doc','2021-01-28 21:13:00','2021-01-28 21:13:00'),(7,'App\\Models\\Module','2','1qLtNBfx5sUnrwD_ULvir3at1hfh6r4Eq','qMpBEYRJzY4UI8cLC4mCogrwQc0D7gRT33nCt1Jr.txt','1rwkJGklpe4vwmn1bFp18r1uD3BycZLytU7Qkmyo.txt','2021-01-28 21:16:26','2021-01-28 21:16:26'),(8,'App\\Models\\Module','2','1OWpFyI-xIRcgZnNNNSLVta6FMhHxyYXw','Final (1).pptx','lkNqJGfK5WkYY8PvGQ718hSBvfRP1K9RzIsBjc6S.pptx','2021-01-28 21:16:36','2021-01-28 21:16:36'),(9,'App\\Models\\Module','2','1XBr2cCkwCL0Fl2bAk1dCm_brvkOM9Pqt','home.html','OzFV4fWt4jkV8Mhxozar7B4DMlvTJ5umK7mHbk28.html','2021-01-28 21:16:39','2021-01-28 21:16:39');
/*!40000 ALTER TABLE `files` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `images` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `imageable_id` bigint unsigned NOT NULL,
  `imageable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=245 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (1,12,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(2,13,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(3,17,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(4,29,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(5,30,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(6,31,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(7,32,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(8,33,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(9,34,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(10,35,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(11,36,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(12,37,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(13,38,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(14,39,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(15,40,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(16,41,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(17,42,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(18,43,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(19,44,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(20,45,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(21,46,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(22,47,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(23,48,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(24,49,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(25,50,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(26,51,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(27,52,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(28,55,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(29,56,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(30,57,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(31,58,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(32,59,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(33,60,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(34,61,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(35,62,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(36,63,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(37,64,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(38,65,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(39,66,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(40,67,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(41,68,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(42,69,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(43,70,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(44,71,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(45,72,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(46,73,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(47,74,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(48,75,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(49,76,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(50,77,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(51,78,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(52,79,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(53,80,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(54,81,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(55,82,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(56,83,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(57,84,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(58,85,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(59,86,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(60,87,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(61,88,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(62,89,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(63,90,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(64,91,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(65,92,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(66,93,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(67,94,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(68,95,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(69,96,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(70,97,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(71,98,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(72,99,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(73,100,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(74,101,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(75,102,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(76,103,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(77,104,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(78,105,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(79,106,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(80,107,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(81,108,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(82,109,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:51','2021-01-28 20:09:51'),(83,110,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(84,111,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(85,112,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(86,113,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(87,114,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(88,115,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(89,116,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(90,117,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(91,118,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(92,119,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(93,120,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(94,121,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(95,122,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(96,123,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(97,124,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(98,125,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(99,126,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(100,127,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(101,128,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(102,129,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(103,130,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(104,131,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(105,132,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(106,133,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(107,134,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(108,135,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(109,136,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(110,137,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(111,138,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(112,139,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(113,140,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(114,141,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(115,142,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(116,143,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(117,144,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(118,145,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(119,146,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(120,147,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(121,148,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(122,149,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(123,150,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(124,151,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:52','2021-01-28 20:09:52'),(125,152,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(126,154,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(127,155,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(128,156,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(129,157,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(130,158,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(131,159,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(132,160,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(133,161,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(134,162,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(135,163,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(136,164,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(137,165,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(138,166,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(139,171,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(140,172,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(141,173,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(142,174,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(143,175,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(144,179,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(145,181,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(146,182,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(147,183,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(148,184,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(149,186,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(150,187,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(151,188,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(152,189,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(153,190,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(154,191,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(155,192,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(156,193,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(157,194,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(158,195,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(159,196,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(160,197,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(161,198,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(162,199,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(163,200,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(164,201,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(165,202,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(166,203,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(167,204,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(168,205,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(169,206,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(170,207,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(171,208,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(172,209,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(173,210,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(174,211,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(175,212,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(176,213,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(177,214,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(178,215,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(179,216,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(180,217,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(181,218,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(182,219,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(183,220,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(184,221,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(185,222,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(186,223,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(187,224,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(188,225,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(189,226,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(190,227,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(191,228,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(192,229,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(193,230,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(194,231,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(195,232,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(196,233,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:53','2021-01-28 20:09:53'),(197,234,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(198,235,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(199,236,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(200,237,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(201,238,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(202,239,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(203,240,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(204,241,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(205,243,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(206,246,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(207,247,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(208,248,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(209,249,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(210,250,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(211,251,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(212,252,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(213,253,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(214,254,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(215,255,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(216,256,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(217,257,'App\\Models\\Course','/img/bg/bg(7).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(218,258,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(219,260,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(220,261,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(221,262,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(222,263,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(223,266,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(224,267,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(225,268,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(226,269,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(227,270,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(228,272,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(229,273,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(230,274,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(231,276,'App\\Models\\Course','/img/bg/bg(6).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(232,278,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(233,279,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(234,281,'App\\Models\\Course','/img/bg/bg(2).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(235,282,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(236,283,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(237,284,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(238,285,'App\\Models\\Course','/img/bg/bg(3).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(239,287,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(240,288,'App\\Models\\Course','/img/bg/bg(1).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(241,289,'App\\Models\\Course','/img/bg/bg(4).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(242,290,'App\\Models\\Course','/img/bg/bg(5).jpg','2021-01-28 20:09:54','2021-01-28 20:09:54'),(243,1,'App\\Models\\Module','/img/bg/bg(5).jpg','2021-01-28 20:17:41','2021-01-28 20:17:41'),(244,2,'App\\Models\\Module','/img/bg/bg(2).jpg','2021-01-28 21:16:39','2021-01-28 21:16:39');
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
INSERT INTO `jobs` VALUES (1,'default','{\"uuid\":\"76a6b53c-f818-4e5f-b3ea-96256d3f59b1\",\"displayName\":\"App\\\\Notifications\\\\GeneralNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":14:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:4;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:37:\\\"App\\\\Notifications\\\\GeneralNotification\\\":13:{s:7:\\\"message\\\";s:31:\\\"Your workload has been updated.\\\";s:9:\\\"photo_url\\\";N;s:3:\\\"url\\\";s:36:\\\"http:\\/\\/elms.test\\/teacher\\/my-workload\\\";s:2:\\\"id\\\";s:36:\\\"99885647-1fa6-4f07-a00a-0e8ee16d54b3\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}',0,NULL,1611865032,1611865032),(2,'default','{\"uuid\":\"234d09d4-928b-4dac-ba51-024db0d362e9\",\"displayName\":\"App\\\\Notifications\\\\GeneralNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":14:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:4;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:37:\\\"App\\\\Notifications\\\\GeneralNotification\\\":13:{s:7:\\\"message\\\";s:31:\\\"Your workload has been updated.\\\";s:9:\\\"photo_url\\\";N;s:3:\\\"url\\\";s:36:\\\"http:\\/\\/elms.test\\/teacher\\/my-workload\\\";s:2:\\\"id\\\";s:36:\\\"99885647-1fa6-4f07-a00a-0e8ee16d54b3\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:9:\\\"broadcast\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}',0,NULL,1611865032,1611865032),(3,'default','{\"uuid\":\"c53eb90a-2dde-44b4-9277-97cf9b3faa6b\",\"displayName\":\"App\\\\Notifications\\\\GeneralNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":14:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:100;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:37:\\\"App\\\\Notifications\\\\GeneralNotification\\\":13:{s:7:\\\"message\\\";s:42:\\\"You have been enrolled to IS130 (IS - 4A).\\\";s:9:\\\"photo_url\\\";N;s:3:\\\"url\\\";s:29:\\\"http:\\/\\/elms.test\\/student\\/home\\\";s:2:\\\"id\\\";s:36:\\\"f3f7f26f-841b-447a-bb01-fb143ac68215\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}',0,NULL,1611865149,1611865149),(4,'default','{\"uuid\":\"7f1838ac-1fe5-4b53-9def-a64dad040241\",\"displayName\":\"App\\\\Notifications\\\\GeneralNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":14:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:100;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:37:\\\"App\\\\Notifications\\\\GeneralNotification\\\":13:{s:7:\\\"message\\\";s:42:\\\"You have been enrolled to IS130 (IS - 4A).\\\";s:9:\\\"photo_url\\\";N;s:3:\\\"url\\\";s:29:\\\"http:\\/\\/elms.test\\/student\\/home\\\";s:2:\\\"id\\\";s:36:\\\"f3f7f26f-841b-447a-bb01-fb143ac68215\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:9:\\\"broadcast\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}',0,NULL,1611865149,1611865149),(5,'default','{\"uuid\":\"7e3e4885-5ea9-436c-840d-9659b2bc4672\",\"displayName\":\"App\\\\Notifications\\\\GeneralNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:18;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:37:\\\"App\\\\Notifications\\\\GeneralNotification\\\":14:{s:7:\\\"message\\\";s:42:\\\"You have been enrolled to AR214 (CS - 2A).\\\";s:9:\\\"photo_url\\\";N;s:3:\\\"url\\\";s:29:\\\"http:\\/\\/elms.test\\/student\\/home\\\";s:2:\\\"id\\\";s:36:\\\"abe5e01a-45c9-4cf5-93ba-69b0cc5f5c83\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}',0,NULL,1611870485,1611870485),(6,'default','{\"uuid\":\"52535d56-feff-4875-9c70-e9520fb68428\",\"displayName\":\"App\\\\Notifications\\\\GeneralNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:18;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:37:\\\"App\\\\Notifications\\\\GeneralNotification\\\":14:{s:7:\\\"message\\\";s:42:\\\"You have been enrolled to AR214 (CS - 2A).\\\";s:9:\\\"photo_url\\\";N;s:3:\\\"url\\\";s:29:\\\"http:\\/\\/elms.test\\/student\\/home\\\";s:2:\\\"id\\\";s:36:\\\"abe5e01a-45c9-4cf5-93ba-69b0cc5f5c83\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:9:\\\"broadcast\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}',0,NULL,1611870485,1611870485),(7,'default','{\"uuid\":\"9db38ef7-36ad-45ac-b559-886d8c4a26df\",\"displayName\":\"App\\\\Notifications\\\\GeneralNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:101;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:37:\\\"App\\\\Notifications\\\\GeneralNotification\\\":14:{s:7:\\\"message\\\";s:42:\\\"You have been enrolled to AR214 (CS - 2A).\\\";s:9:\\\"photo_url\\\";N;s:3:\\\"url\\\";s:29:\\\"http:\\/\\/elms.test\\/student\\/home\\\";s:2:\\\"id\\\";s:36:\\\"bd8a22f2-c7ae-4c38-a82a-849796fb6729\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:8:\\\"database\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}',0,NULL,1611870520,1611870520),(8,'default','{\"uuid\":\"b4fac2c9-846f-437d-8355-2f99db75874b\",\"displayName\":\"App\\\\Notifications\\\\GeneralNotification\",\"job\":\"Illuminate\\\\Queue\\\\CallQueuedHandler@call\",\"maxTries\":null,\"maxExceptions\":null,\"backoff\":\"\",\"timeout\":null,\"retryUntil\":null,\"data\":{\"commandName\":\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\",\"command\":\"O:48:\\\"Illuminate\\\\Notifications\\\\SendQueuedNotifications\\\":16:{s:11:\\\"notifiables\\\";O:45:\\\"Illuminate\\\\Contracts\\\\Database\\\\ModelIdentifier\\\":4:{s:5:\\\"class\\\";s:15:\\\"App\\\\Models\\\\User\\\";s:2:\\\"id\\\";a:1:{i:0;i:101;}s:9:\\\"relations\\\";a:0:{}s:10:\\\"connection\\\";s:5:\\\"mysql\\\";}s:12:\\\"notification\\\";O:37:\\\"App\\\\Notifications\\\\GeneralNotification\\\":14:{s:7:\\\"message\\\";s:42:\\\"You have been enrolled to AR214 (CS - 2A).\\\";s:9:\\\"photo_url\\\";N;s:3:\\\"url\\\";s:29:\\\"http:\\/\\/elms.test\\/student\\/home\\\";s:2:\\\"id\\\";s:36:\\\"bd8a22f2-c7ae-4c38-a82a-849796fb6729\\\";s:6:\\\"locale\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}s:8:\\\"channels\\\";a:1:{i:0;s:9:\\\"broadcast\\\";}s:5:\\\"tries\\\";N;s:7:\\\"timeout\\\";N;s:17:\\\"shouldBeEncrypted\\\";b:0;s:3:\\\"job\\\";N;s:10:\\\"connection\\\";N;s:5:\\\"queue\\\";N;s:15:\\\"chainConnection\\\";N;s:10:\\\"chainQueue\\\";N;s:19:\\\"chainCatchCallbacks\\\";N;s:5:\\\"delay\\\";N;s:11:\\\"afterCommit\\\";N;s:10:\\\"middleware\\\";a:0:{}s:7:\\\"chained\\\";a:0:{}}\"}}',0,NULL,1611870520,1611870520);
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` bigint unsigned NOT NULL,
  `receiver_id` bigint unsigned NOT NULL,
  `message` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `messages_sender_id_foreign` (`sender_id`),
  KEY `messages_receiver_id_foreign` (`receiver_id`),
  CONSTRAINT `messages_receiver_id_foreign` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`),
  CONSTRAINT `messages_sender_id_foreign` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2012_01_16_225720_create_campus_table',1),(2,'2013_09_27_153834_create_roles_table',1),(3,'2014_10_12_000000_create_users_table',1),(4,'2014_10_12_100000_create_password_resets_table',1),(5,'2014_10_12_200000_add_two_factor_columns_to_users_table',1),(6,'2019_08_19_000000_create_failed_jobs_table',1),(7,'2019_12_14_000001_create_personal_access_tokens_table',1),(8,'2020_09_18_040218_create_sessions_table',1),(9,'2020_09_21_002016_create_colleges_table',1),(10,'2020_09_21_002955_create_departments_table',1),(11,'2020_09_22_002107_create_courses_table',1),(12,'2020_09_22_002407_create_teachers_table',1),(13,'2020_09_22_002434_create_program_heads_table',1),(14,'2020_09_22_002436_create_students_table',1),(15,'2020_09_22_002445_create_deans_table',1),(16,'2020_09_22_002453_create_sections_table',1),(17,'2020_09_22_002454_create_modules_table',1),(18,'2020_09_22_002609_create_resources_table',1),(19,'2020_09_27_125643_create_files_table',1),(20,'2020_09_28_094142_create_course_teacher_table',1),(21,'2020_09_28_135549_create_course_modules_table',1),(22,'2020_10_05_010318_create_student_teacher_table',1),(23,'2020_10_10_220419_create_role_user_table',1),(24,'2020_10_11_201048_create_calendar_events_table',1),(25,'2020_10_16_214531_create_task_types_table',1),(26,'2020_10_16_214622_create_tasks_table',1),(27,'2020_10_16_214823_create_student_task_table',1),(28,'2020_11_04_163152_create_images_table',1),(29,'2020_11_04_205831_create_todos_table',1),(30,'2020_11_04_231151_add_status_column_to_todos_table',1),(31,'2020_11_06_014707_create_jobs_table',1),(32,'2020_11_08_161514_create_notifications_table',1),(33,'2020_12_07_225520_create_prospectus_table',1),(34,'2020_12_14_235029_create_extensions_table',1),(35,'2020_12_16_170049_add_assessment_column_to_student_task_table',1),(36,'2020_12_19_024310_add_autocorrect_to_tasks_table',1),(37,'2020_12_21_001008_add_matchingtype_options_to_tasks_table',1),(38,'2021_01_06_120849_create_messages_table',1),(39,'2021_01_22_182435_create_videorooms_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `modules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `modules` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `course_id` bigint unsigned NOT NULL,
  `section_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `modules_course_id_foreign` (`course_id`),
  KEY `modules_section_id_foreign` (`section_id`),
  CONSTRAINT `modules_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `modules_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `modules` WRITE;
/*!40000 ALTER TABLE `modules` DISABLE KEYS */;
INSERT INTO `modules` VALUES (1,144,1,'Lesson 1','2021-01-28 20:17:33','2021-01-28 20:17:33'),(2,144,1,'Lesson 2','2021-01-28 21:16:23','2021-01-28 21:16:23');
/*!40000 ALTER TABLE `modules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `program_heads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `program_heads` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `college_id` bigint unsigned NOT NULL,
  `department_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `program_heads_user_id_foreign` (`user_id`),
  KEY `program_heads_college_id_foreign` (`college_id`),
  KEY `program_heads_department_id_foreign` (`department_id`),
  CONSTRAINT `program_heads_college_id_foreign` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`id`),
  CONSTRAINT `program_heads_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `program_heads_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `program_heads` WRITE;
/*!40000 ALTER TABLE `program_heads` DISABLE KEYS */;
INSERT INTO `program_heads` VALUES (1,4,2,4,'2021-01-28 20:16:18','2021-01-28 20:16:18');
/*!40000 ALTER TABLE `program_heads` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `prospectus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prospectus` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `program_id` bigint unsigned NOT NULL,
  `subject_id` bigint unsigned NOT NULL,
  `yearlevel` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `semester` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revision` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preqreq1` bigint unsigned NOT NULL,
  `preqreq2` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=428 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `prospectus` WRITE;
/*!40000 ALTER TABLE `prospectus` DISABLE KEYS */;
INSERT INTO `prospectus` VALUES (81,1,12,'1','1','UNDEFINED',54,54,NULL,NULL),(82,1,31,'1','1','UNDEFINED',54,54,NULL,NULL),(83,1,32,'1','1','UNDEFINED',54,54,NULL,NULL),(84,1,33,'1','1','UNDEFINED',54,54,NULL,NULL),(85,1,34,'1','1','UNDEFINED',54,54,NULL,NULL),(86,1,35,'1','1','UNDEFINED',54,54,NULL,NULL),(87,1,36,'1','1','UNDEFINED',54,54,NULL,NULL),(88,1,37,'1','1','UNDEFINED',54,54,NULL,NULL),(89,1,38,'1','2','UNDEFINED',31,54,NULL,NULL),(90,1,39,'1','2','UNDEFINED',32,54,NULL,NULL),(91,1,40,'1','2','UNDEFINED',34,54,NULL,NULL),(92,1,41,'1','2','UNDEFINED',54,54,NULL,NULL),(93,1,42,'1','2','UNDEFINED',54,54,NULL,NULL),(94,1,43,'1','2','UNDEFINED',54,54,NULL,NULL),(95,1,44,'1','2','UNDEFINED',36,54,NULL,NULL),(96,1,45,'1','2','UNDEFINED',37,54,NULL,NULL),(97,1,55,'2','1','UNDEFINED',38,54,NULL,NULL),(98,1,30,'2','1','UNDEFINED',39,54,NULL,NULL),(99,1,57,'2','1','UNDEFINED',38,54,NULL,NULL),(100,1,58,'2','1','UNDEFINED',39,40,NULL,NULL),(101,1,59,'2','1','UNDEFINED',40,54,NULL,NULL),(102,1,60,'2','1','UNDEFINED',54,54,NULL,NULL),(103,1,61,'2','1','UNDEFINED',54,54,NULL,NULL),(104,1,62,'2','1','UNDEFINED',36,54,NULL,NULL),(105,1,63,'2','2','UNDEFINED',30,54,NULL,NULL),(106,1,64,'2','2','UNDEFINED',55,54,NULL,NULL),(107,1,65,'2','2','UNDEFINED',55,54,NULL,NULL),(108,1,66,'2','2','UNDEFINED',55,54,NULL,NULL),(109,1,67,'2','2','UNDEFINED',57,54,NULL,NULL),(110,1,68,'2','2','UNDEFINED',54,54,NULL,NULL),(111,1,69,'2','2','UNDEFINED',54,54,NULL,NULL),(112,1,70,'2','2','UNDEFINED',62,54,NULL,NULL),(113,6,12,'1','1','UNDEFINED',54,54,NULL,NULL),(114,1,71,'3','1','UNDEFINED',64,54,NULL,NULL),(115,1,72,'3','1','UNDEFINED',66,54,NULL,NULL),(116,1,73,'3','1','UNDEFINED',64,54,NULL,NULL),(117,1,74,'3','1','UNDEFINED',67,54,NULL,NULL),(118,1,75,'3','1','UNDEFINED',54,54,NULL,NULL),(119,1,76,'3','1','UNDEFINED',67,54,NULL,NULL),(120,1,77,'3','1','UNDEFINED',40,54,NULL,NULL),(121,1,78,'3','1','UNDEFINED',42,54,NULL,NULL),(122,1,79,'3','2','UNDEFINED',72,54,NULL,NULL),(123,1,80,'3','2','UNDEFINED',54,54,NULL,NULL),(124,1,81,'3','2','UNDEFINED',54,54,NULL,NULL),(125,1,82,'3','2','UNDEFINED',66,54,NULL,NULL),(126,1,83,'3','2','UNDEFINED',75,54,NULL,NULL),(127,1,84,'3','2','UNDEFINED',75,54,NULL,NULL),(129,1,86,'4','1','UNDEFINED',54,54,NULL,NULL),(130,1,87,'4','1','UNDEFINED',54,54,NULL,NULL),(131,1,88,'4','1','UNDEFINED',54,54,NULL,NULL),(132,1,89,'4','1','UNDEFINED',54,54,NULL,NULL),(134,1,91,'4','2','UNDEFINED',86,54,NULL,NULL),(135,1,92,'4','2','UNDEFINED',54,54,NULL,NULL),(136,18,93,'1','1','UNDEFINED',54,54,NULL,NULL),(138,18,94,'1','1','UNDEFINED',54,54,NULL,NULL),(139,18,95,'1','1','UNDEFINED',54,54,NULL,NULL),(140,18,96,'1','1','UNDEFINED',54,54,NULL,NULL),(141,18,97,'1','1','UNDEFINED',54,54,NULL,NULL),(142,18,98,'1','1','UNDEFINED',54,54,NULL,NULL),(143,18,99,'1','1','UNDEFINED',54,54,NULL,NULL),(144,18,100,'1','1','UNDEFINED',54,54,NULL,NULL),(145,18,101,'1','1','UNDEFINED',54,54,NULL,NULL),(146,18,102,'1','2','UNDEFINED',54,54,NULL,NULL),(147,18,103,'1','2','UNDEFINED',54,54,NULL,NULL),(148,18,104,'1','2','UNDEFINED',54,54,NULL,NULL),(149,18,105,'1','2','UNDEFINED',54,54,NULL,NULL),(150,18,106,'1','2','UNDEFINED',96,54,NULL,NULL),(151,18,107,'1','2','UNDEFINED',95,54,NULL,NULL),(152,18,108,'1','2','UNDEFINED',97,54,NULL,NULL),(153,18,109,'1','2','UNDEFINED',100,54,NULL,NULL),(154,18,111,'2','1','UNDEFINED',103,54,NULL,NULL),(155,18,112,'2','1','UNDEFINED',102,54,NULL,NULL),(156,18,113,'2','1','UNDEFINED',103,54,NULL,NULL),(157,18,114,'2','1','UNDEFINED',105,54,NULL,NULL),(158,18,115,'2','1','UNDEFINED',97,54,NULL,NULL),(159,18,116,'2','1','UNDEFINED',107,54,NULL,NULL),(160,18,117,'2','1','UNDEFINED',106,54,NULL,NULL),(161,18,118,'2','1','UNDEFINED',108,54,NULL,NULL),(162,18,119,'2','1','UNDEFINED',54,54,NULL,NULL),(163,18,120,'2','2','UNDEFINED',112,113,NULL,NULL),(164,18,121,'2','2','UNDEFINED',113,54,NULL,NULL),(165,18,122,'2','2','UNDEFINED',111,54,NULL,NULL),(166,18,123,'2','2','UNDEFINED',54,54,NULL,NULL),(167,18,124,'2','2','UNDEFINED',114,54,NULL,NULL),(168,18,125,'2','2','UNDEFINED',97,54,NULL,NULL),(169,18,126,'2','2','UNDEFINED',118,54,NULL,NULL),(170,18,127,'2','2','UNDEFINED',54,54,NULL,NULL),(171,18,128,'3','1','UNDEFINED',120,54,NULL,NULL),(172,18,129,'3','1','UNDEFINED',120,54,NULL,NULL),(173,18,130,'3','1','UNDEFINED',124,54,NULL,NULL),(174,18,132,'3','1','UNDEFINED',54,54,NULL,NULL),(175,18,133,'3','1','UNDEFINED',54,54,NULL,NULL),(176,18,134,'3','1','UNDEFINED',117,54,NULL,NULL),(177,18,135,'3','1','UNDEFINED',54,54,NULL,NULL),(178,18,136,'3','2','UNDEFINED',128,54,NULL,NULL),(179,18,137,'3','2','UNDEFINED',54,54,NULL,NULL),(180,18,138,'3','2','UNDEFINED',54,54,NULL,NULL),(181,18,139,'3','2','UNDEFINED',54,54,NULL,NULL),(182,18,140,'3','2','UNDEFINED',54,54,NULL,NULL),(183,18,81,'3','2','UNDEFINED',54,54,NULL,NULL),(184,18,142,'3','2','UNDEFINED',54,54,NULL,NULL),(185,18,143,'3','2','UNDEFINED',54,54,NULL,NULL),(186,18,144,'4','1','UNDEFINED',54,54,NULL,NULL),(187,18,145,'4','2','UNDEFINED',144,54,NULL,NULL),(188,18,146,'4','2','UNDEFINED',122,54,NULL,NULL),(189,18,147,'4','2','UNDEFINED',54,54,NULL,NULL),(190,18,148,'4','2','UNDEFINED',54,54,NULL,NULL),(191,18,149,'4','2','UNDEFINED',104,54,NULL,NULL),(192,18,110,'1','2','UNDEFINED',54,54,NULL,NULL),(194,17,150,'1','1','UNDEFINED',54,54,NULL,NULL),(195,17,151,'1','1','UNDEFINED',54,54,NULL,NULL),(196,17,152,'1','1','UNDEFINED',54,54,NULL,NULL),(197,17,96,'1','1','UNDEFINED',54,54,NULL,NULL),(198,17,95,'1','1','UNDEFINED',54,54,NULL,NULL),(199,17,97,'1','1','UNDEFINED',54,54,NULL,NULL),(200,17,99,'1','1','UNDEFINED',54,54,NULL,NULL),(201,17,100,'1','1','UNDEFINED',54,54,NULL,NULL),(204,17,158,'1','2','UNDEFINED',150,54,NULL,NULL),(205,17,107,'1','2','UNDEFINED',95,54,NULL,NULL),(206,17,108,'1','2','UNDEFINED',97,54,NULL,NULL),(207,17,171,'1','2','UNDEFINED',54,54,NULL,NULL),(208,17,172,'1','2','UNDEFINED',54,54,NULL,NULL),(209,17,109,'1','2','UNDEFINED',100,54,NULL,NULL),(210,17,110,'1','2','UNDEFINED',101,54,NULL,NULL),(211,17,101,'1','1','UNDEFINED',54,54,NULL,NULL),(212,17,154,'2','1','UNDEFINED',151,54,NULL,NULL),(213,17,155,'2','1','UNDEFINED',97,54,NULL,NULL),(214,17,117,'2','1','UNDEFINED',106,54,NULL,NULL),(215,17,124,'2','1','UNDEFINED',108,54,NULL,NULL),(216,17,116,'2','1','UNDEFINED',107,54,NULL,NULL),(217,17,119,'2','1','UNDEFINED',109,54,NULL,NULL),(218,17,159,'2','2','UNDEFINED',156,54,NULL,NULL),(219,17,160,'2','2','UNDEFINED',154,54,NULL,NULL),(220,17,161,'2','2','UNDEFINED',156,54,NULL,NULL),(221,17,162,'2','2','UNDEFINED',154,54,NULL,NULL),(222,17,186,'2','2','UNDEFINED',54,54,NULL,NULL),(223,17,123,'2','2','UNDEFINED',54,54,NULL,NULL),(224,17,118,'2','1','UNDEFINED',108,54,NULL,NULL),(225,17,126,'2','2','UNDEFINED',118,54,NULL,NULL),(226,17,127,'2','2','UNDEFINED',119,54,NULL,NULL),(227,17,163,'3','1','UNDEFINED',159,54,NULL,NULL),(228,17,119,'2','1','UNDEFINED',109,54,NULL,NULL),(229,17,164,'3','1','UNDEFINED',159,54,NULL,NULL),(230,17,165,'3','1','UNDEFINED',161,54,NULL,NULL),(231,17,125,'3','1','UNDEFINED',97,54,NULL,NULL),(232,17,134,'3','1','UNDEFINED',117,54,NULL,NULL),(233,17,135,'3','1','UNDEFINED',54,54,NULL,NULL),(234,17,166,'3','1','UNDEFINED',54,54,NULL,NULL),(235,17,173,'3','2','UNDEFINED',163,54,NULL,NULL),(236,17,174,'3','2','UNDEFINED',165,54,NULL,NULL),(237,17,175,'3','2','UNDEFINED',54,54,NULL,NULL),(238,17,133,'3','2','UNDEFINED',54,54,NULL,NULL),(239,17,140,'3','2','UNDEFINED',54,54,NULL,NULL),(240,17,179,'3','2','UNDEFINED',158,54,NULL,NULL),(241,17,81,'3','2','UNDEFINED',54,54,NULL,NULL),(242,17,142,'3','2','UNDEFINED',54,54,NULL,NULL),(243,17,143,'3','2','UNDEFINED',54,54,NULL,NULL),(244,17,181,'4','1','UNDEFINED',54,54,NULL,NULL),(245,17,182,'4','2','UNDEFINED',54,54,NULL,NULL),(246,17,187,'4','2','UNDEFINED',54,54,NULL,NULL),(247,17,183,'4','2','UNDEFINED',54,54,NULL,NULL),(248,17,184,'4','2','UNDEFINED',181,54,NULL,NULL),(249,17,147,'4','2','UNDEFINED',54,54,NULL,NULL),(250,17,157,'1','2','UNDEFINED',151,54,NULL,NULL),(251,18,131,'3','1','UNDEFINED',124,54,NULL,NULL),(253,6,46,'1','1','UNDEFINED',54,54,NULL,NULL),(256,6,47,'1','1','UNDEFINED',54,54,NULL,NULL),(257,6,188,'1','1','UNDEFINED',54,54,NULL,NULL),(258,6,33,'1','1','UNDEFINED',54,54,NULL,NULL),(259,6,43,'1','1','UNDEFINED',54,54,NULL,NULL),(260,6,34,'1','1','UNDEFINED',54,54,NULL,NULL),(261,6,36,'1','1','UNDEFINED',54,54,NULL,NULL),(262,6,37,'1','1','UNDEFINED',54,54,NULL,NULL),(263,6,49,'1','2','UNDEFINED',46,54,NULL,NULL),(264,6,50,'1','2','UNDEFINED',12,47,NULL,NULL),(265,6,51,'1','2','UNDEFINED',54,54,NULL,NULL),(266,6,189,'1','2','UNDEFINED',188,54,NULL,NULL),(267,6,42,'1','2','UNDEFINED',54,54,NULL,NULL),(268,6,41,'1','2','UNDEFINED',33,54,NULL,NULL),(269,6,90,'1','2','UNDEFINED',54,54,NULL,NULL),(270,6,44,'1','2','UNDEFINED',54,54,NULL,NULL),(271,6,45,'1','2','UNDEFINED',37,54,NULL,NULL),(272,6,56,'2','1','UNDEFINED',49,54,NULL,NULL),(273,6,190,'2','1','UNDEFINED',54,54,NULL,NULL),(274,6,191,'2','1','UNDEFINED',189,54,NULL,NULL),(275,6,35,'2','1','UNDEFINED',54,54,NULL,NULL),(276,6,61,'2','1','UNDEFINED',54,54,NULL,NULL),(277,6,68,'2','1','UNDEFINED',54,54,NULL,NULL),(278,6,69,'2','1','UNDEFINED',54,54,NULL,NULL),(279,6,192,'2','1','UNDEFINED',54,54,NULL,NULL),(280,6,194,'2','2','UNDEFINED',54,54,NULL,NULL),(281,6,195,'2','2','UNDEFINED',50,49,NULL,NULL),(282,6,196,'2','2','UNDEFINED',191,54,NULL,NULL),(283,6,66,'2','2','UNDEFINED',56,54,NULL,NULL),(284,6,197,'2','2','UNDEFINED',54,54,NULL,NULL),(285,6,77,'2','2','UNDEFINED',34,54,NULL,NULL),(286,6,193,'2','2','UNDEFINED',54,54,NULL,NULL),(287,6,198,'3','1','UNDEFINED',196,54,NULL,NULL),(289,6,199,'3','1','UNDEFINED',195,54,NULL,NULL),(290,6,200,'3','1','UNDEFINED',194,54,NULL,NULL),(291,6,201,'3','1','UNDEFINED',54,54,NULL,NULL),(292,6,202,'3','1','UNDEFINED',54,54,NULL,NULL),(293,6,203,'3','1','UNDEFINED',54,54,NULL,NULL),(294,6,60,'3','1','UNDEFINED',54,54,NULL,NULL),(295,6,204,'3','2','UNDEFINED',199,54,NULL,NULL),(296,6,205,'3','2','UNDEFINED',54,54,NULL,NULL),(297,6,78,'3','2','UNDEFINED',42,54,NULL,NULL),(298,6,206,'3','2','UNDEFINED',54,54,NULL,NULL),(299,6,210,'3','2','UNDEFINED',54,54,NULL,NULL),(300,6,80,'3','2','UNDEFINED',54,54,NULL,NULL),(301,6,207,'4','1','UNDEFINED',54,54,NULL,NULL),(302,6,89,'4','1','UNDEFINED',54,54,NULL,NULL),(303,6,208,'4','1','UNDEFINED',205,54,NULL,NULL),(304,6,88,'4','1','UNDEFINED',54,54,NULL,NULL),(305,6,209,'4','2','UNDEFINED',54,54,NULL,NULL),(306,19,12,'1','1','UNDEFINED',54,54,NULL,NULL),(307,19,46,'1','1','UNDEFINED',54,54,NULL,NULL),(308,19,34,'1','1','UNDEFINED',54,54,NULL,NULL),(309,19,42,'1','1','UNDEFINED',54,54,NULL,NULL),(310,19,90,'1','1','UNDEFINED',54,54,NULL,NULL),(311,19,43,'1','1','UNDEFINED',54,54,NULL,NULL),(312,19,33,'1','1','UNDEFINED',54,54,NULL,NULL),(313,19,36,'1','1','UNDEFINED',54,54,NULL,NULL),(314,19,37,'1','1','UNDEFINED',54,54,NULL,NULL),(315,19,49,'1','2','UNDEFINED',46,54,NULL,NULL),(316,19,212,'1','2','UNDEFINED',34,54,NULL,NULL),(317,19,213,'1','2','UNDEFINED',46,54,NULL,NULL),(318,19,69,'1','2','UNDEFINED',54,54,NULL,NULL),(319,19,60,'1','2','UNDEFINED',54,54,NULL,NULL),(320,19,89,'1','2','UNDEFINED',54,54,NULL,NULL),(321,19,41,'1','2','UNDEFINED',33,54,NULL,NULL),(322,19,44,'1','2','UNDEFINED',54,54,NULL,NULL),(323,19,45,'1','2','UNDEFINED',37,54,NULL,NULL),(324,19,214,'2','1','UNDEFINED',49,54,NULL,NULL),(325,19,215,'2','1','UNDEFINED',49,54,NULL,NULL),(326,19,56,'2','1','UNDEFINED',49,54,NULL,NULL),(327,19,66,'2','1','UNDEFINED',49,54,NULL,NULL),(328,19,216,'2','1','UNDEFINED',54,54,NULL,NULL),(329,19,235,'2','1','UNDEFINED',34,54,NULL,NULL),(330,19,192,'2','1','UNDEFINED',54,54,NULL,NULL),(331,19,217,'2','2','UNDEFINED',56,54,NULL,NULL),(332,19,218,'2','2','UNDEFINED',214,215,NULL,NULL),(333,19,219,'2','2','UNDEFINED',66,54,NULL,NULL),(334,19,220,'2','2','UNDEFINED',49,54,NULL,NULL),(335,19,236,'2','2','UNDEFINED',235,54,NULL,NULL),(336,19,77,'2','2','UNDEFINED',34,54,NULL,NULL),(337,19,35,'2','2','UNDEFINED',54,54,NULL,NULL),(338,19,193,'2','2','UNDEFINED',54,54,NULL,NULL),(339,19,221,'3','1','UNDEFINED',77,54,NULL,NULL),(340,19,228,'3','1','UNDEFINED',218,54,NULL,NULL),(341,19,223,'3','1','UNDEFINED',225,54,NULL,NULL),(342,19,207,'3','1','UNDEFINED',219,54,NULL,NULL),(343,19,225,'3','1','UNDEFINED',218,54,NULL,NULL),(344,19,226,'3','1','UNDEFINED',215,54,NULL,NULL),(345,19,227,'3','2','UNDEFINED',228,54,NULL,NULL),(346,19,224,'3','2','UNDEFINED',223,54,NULL,NULL),(347,19,229,'3','2','UNDEFINED',226,54,NULL,NULL),(348,19,230,'3','2','UNDEFINED',223,207,NULL,NULL),(349,19,231,'3','2','UNDEFINED',54,54,NULL,NULL),(350,19,232,'3','2','UNDEFINED',217,54,NULL,NULL),(351,19,237,'4','1','UNDEFINED',54,54,NULL,NULL),(352,19,233,'4','2','UNDEFINED',230,54,NULL,NULL),(353,19,234,'4','2','UNDEFINED',224,54,NULL,NULL),(354,19,68,'4','2','UNDEFINED',54,54,NULL,NULL),(355,19,61,'4','2','UNDEFINED',54,54,NULL,NULL),(356,19,88,'4','2','UNDEFINED',54,54,NULL,NULL),(357,17,156,'3','1','UNDEFINED',157,54,NULL,NULL),(358,17,106,'1','2','UNDEFINED',96,54,NULL,NULL),(359,19,240,'2','1','UNDEFINED',54,54,NULL,NULL),(360,20,241,'1','1','UNDEFINED',54,54,NULL,NULL),(361,20,256,'1','1','UNDEFINED',54,54,NULL,NULL),(362,20,96,'1','1','UNDEFINED',54,54,NULL,NULL),(363,20,95,'1','1','UNDEFINED',54,54,NULL,NULL),(364,20,97,'1','1','UNDEFINED',54,54,NULL,NULL),(365,20,101,'1','1','UNDEFINED',54,54,NULL,NULL),(366,20,100,'1','1','UNDEFINED',54,54,NULL,NULL),(367,20,99,'1','1','UNDEFINED',54,54,NULL,NULL),(368,20,243,'1','2','UNDEFINED',241,54,NULL,NULL),(369,20,246,'1','2','UNDEFINED',243,54,NULL,NULL),(370,20,247,'1','2','UNDEFINED',54,54,NULL,NULL),(371,20,106,'1','2','UNDEFINED',96,54,NULL,NULL),(375,20,107,'1','2','UNDEFINED',95,54,NULL,NULL),(376,20,108,'1','2','UNDEFINED',97,54,NULL,NULL),(377,20,110,'1','2','UNDEFINED',101,54,NULL,NULL),(379,20,117,'2','1','UNDEFINED',106,54,NULL,NULL),(380,20,116,'2','1','UNDEFINED',107,54,NULL,NULL),(381,20,248,'2','1','UNDEFINED',243,54,NULL,NULL),(382,20,249,'2','1','UNDEFINED',97,54,NULL,NULL),(383,20,250,'2','1','UNDEFINED',246,54,NULL,NULL),(384,20,251,'2','1','UNDEFINED',108,54,NULL,NULL),(386,20,257,'2','1','UNDEFINED',97,54,NULL,NULL),(388,20,253,'2','2','UNDEFINED',249,54,NULL,NULL),(389,20,252,'2','2','UNDEFINED',248,54,NULL,NULL),(390,20,254,'2','2','UNDEFINED',248,54,NULL,NULL),(391,20,255,'2','2','UNDEFINED',108,54,NULL,NULL),(392,20,260,'2','2','UNDEFINED',251,54,NULL,NULL),(393,20,186,'2','2','UNDEFINED',54,54,NULL,NULL),(394,20,127,'2','2','UNDEFINED',119,54,NULL,NULL),(395,20,258,'2','2','UNDEFINED',257,54,NULL,NULL),(396,20,261,'3','1','UNDEFINED',255,54,NULL,NULL),(397,20,262,'3','1','UNDEFINED',248,54,NULL,NULL),(398,20,263,'3','1','UNDEFINED',97,54,NULL,NULL),(399,20,287,'3','1','UNDEFINED',253,54,NULL,NULL),(400,20,288,'3','1','UNDEFINED',54,54,NULL,NULL),(401,20,134,'3','1','UNDEFINED',106,54,NULL,NULL),(402,20,267,'3','1','UNDEFINED',54,54,NULL,NULL),(403,20,268,'3','1','UNDEFINED',108,54,NULL,NULL),(404,20,269,'3','2','UNDEFINED',253,54,NULL,NULL),(405,20,270,'3','2','UNDEFINED',261,54,NULL,NULL),(406,20,272,'3','2','UNDEFINED',54,54,NULL,NULL),(407,20,133,'3','2','UNDEFINED',54,54,NULL,NULL),(408,20,143,'3','2','UNDEFINED',54,54,NULL,NULL),(409,20,172,'3','2','UNDEFINED',54,54,NULL,NULL),(410,20,276,'3','2','UNDEFINED',54,54,NULL,NULL),(411,20,142,'3','2','UNDEFINED',54,54,NULL,NULL),(413,20,278,'3','3','UNDEFINED',54,54,NULL,NULL),(415,1,85,'3','3','UNDEFINED',54,54,NULL,NULL),(416,20,279,'4','1','UNDEFINED',270,54,NULL,NULL),(417,20,281,'4','1','UNDEFINED',278,54,NULL,NULL),(418,20,282,'4','1','UNDEFINED',54,54,NULL,NULL),(419,20,123,'4','1','UNDEFINED',54,54,NULL,NULL),(420,20,187,'4','1','UNDEFINED',54,54,NULL,NULL),(421,20,284,'4','2','UNDEFINED',281,54,NULL,NULL),(422,20,285,'4','2','UNDEFINED',54,54,NULL,NULL),(423,20,140,'4','2','UNDEFINED',54,54,NULL,NULL),(424,20,147,'4','2','UNDEFINED',54,54,NULL,NULL),(425,20,109,'1','2','UNDEFINED',100,54,NULL,NULL),(426,20,119,'2','1','UNDEFINED',109,54,NULL,NULL),(427,20,290,'4','2','UNDEFINED',54,54,NULL,NULL);
/*!40000 ALTER TABLE `prospectus` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `resources`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resources` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `teacher_id` bigint unsigned NOT NULL,
  `module_id` bigint unsigned NOT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resources_teacher_id_foreign` (`teacher_id`),
  KEY `resources_module_id_foreign` (`module_id`),
  CONSTRAINT `resources_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`),
  CONSTRAINT `resources_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `resources` WRITE;
/*!40000 ALTER TABLE `resources` DISABLE KEYS */;
INSERT INTO `resources` VALUES (1,4,1,'Resource 1','Resources','2021-01-28 20:55:38','2021-01-28 20:55:38'),(2,4,1,'New Resource','Resourcesssss','2021-01-28 21:12:36','2021-01-28 21:12:36');
/*!40000 ALTER TABLE `resources` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_user` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `role_user_user_id_foreign` (`user_id`),
  KEY `role_user_role_id_foreign` (`role_id`),
  CONSTRAINT `role_user_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`),
  CONSTRAINT `role_user_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
INSERT INTO `role_user` VALUES (1,1,5,NULL,NULL),(2,1,3,NULL,NULL),(3,2,3,NULL,NULL),(4,3,3,NULL,NULL),(5,4,3,NULL,NULL),(6,5,3,NULL,NULL),(7,6,3,NULL,NULL),(8,7,3,NULL,NULL),(9,8,3,NULL,NULL),(10,9,3,NULL,NULL),(11,10,3,NULL,NULL),(12,11,3,NULL,NULL),(13,12,3,NULL,NULL),(14,13,3,NULL,NULL),(15,14,3,NULL,NULL),(16,15,3,NULL,NULL),(17,16,3,NULL,NULL),(18,17,3,NULL,NULL),(19,18,2,NULL,NULL),(20,19,2,NULL,NULL),(21,20,2,NULL,NULL),(22,21,2,NULL,NULL),(23,22,2,NULL,NULL),(24,23,2,NULL,NULL),(25,24,2,NULL,NULL),(26,25,2,NULL,NULL),(27,26,2,NULL,NULL),(28,27,2,NULL,NULL),(29,28,2,NULL,NULL),(30,29,2,NULL,NULL),(31,30,2,NULL,NULL),(32,31,2,NULL,NULL),(33,32,2,NULL,NULL),(34,33,2,NULL,NULL),(35,34,2,NULL,NULL),(36,35,2,NULL,NULL),(37,36,2,NULL,NULL),(38,37,2,NULL,NULL),(39,38,2,NULL,NULL),(40,39,2,NULL,NULL),(41,40,2,NULL,NULL),(42,41,2,NULL,NULL),(43,42,2,NULL,NULL),(44,43,2,NULL,NULL),(45,44,2,NULL,NULL),(46,45,2,NULL,NULL),(47,46,2,NULL,NULL),(48,47,2,NULL,NULL),(49,48,2,NULL,NULL),(50,49,2,NULL,NULL),(51,50,2,NULL,NULL),(52,51,2,NULL,NULL),(53,52,2,NULL,NULL),(54,53,2,NULL,NULL),(55,54,2,NULL,NULL),(56,55,2,NULL,NULL),(57,56,2,NULL,NULL),(58,57,2,NULL,NULL),(59,58,2,NULL,NULL),(60,59,2,NULL,NULL),(61,60,2,NULL,NULL),(62,61,2,NULL,NULL),(63,62,2,NULL,NULL),(64,63,2,NULL,NULL),(65,64,2,NULL,NULL),(66,65,2,NULL,NULL),(67,66,2,NULL,NULL),(68,67,2,NULL,NULL),(69,68,2,NULL,NULL),(70,69,2,NULL,NULL),(71,70,2,NULL,NULL),(72,71,2,NULL,NULL),(73,72,2,NULL,NULL),(74,73,2,NULL,NULL),(75,74,2,NULL,NULL),(76,75,2,NULL,NULL),(77,76,2,NULL,NULL),(78,77,2,NULL,NULL),(79,78,2,NULL,NULL),(80,79,2,NULL,NULL),(81,80,2,NULL,NULL),(82,81,2,NULL,NULL),(83,82,2,NULL,NULL),(84,83,2,NULL,NULL),(85,84,2,NULL,NULL),(86,85,2,NULL,NULL),(87,86,2,NULL,NULL),(88,87,2,NULL,NULL),(89,88,2,NULL,NULL),(90,89,2,NULL,NULL),(91,90,2,NULL,NULL),(92,91,2,NULL,NULL),(93,92,2,NULL,NULL),(94,93,2,NULL,NULL),(95,94,2,NULL,NULL),(96,95,2,NULL,NULL),(97,96,2,NULL,NULL),(98,97,2,NULL,NULL),(99,98,2,NULL,NULL),(100,99,2,NULL,NULL),(101,100,2,NULL,NULL),(102,101,2,NULL,NULL),(103,102,2,NULL,NULL),(104,103,2,NULL,NULL),(105,104,2,NULL,NULL),(106,105,2,NULL,NULL),(107,106,2,NULL,NULL),(108,107,2,NULL,NULL),(109,108,2,NULL,NULL),(110,109,2,NULL,NULL),(111,110,2,NULL,NULL),(112,111,2,NULL,NULL),(113,112,2,NULL,NULL),(114,113,2,NULL,NULL),(115,114,2,NULL,NULL),(116,115,2,NULL,NULL),(117,116,2,NULL,NULL),(118,4,4,NULL,NULL);
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'admin','2021-01-28 20:09:42','2021-01-28 20:09:42'),(2,'student','2021-01-28 20:09:42','2021-01-28 20:09:42'),(3,'teacher','2021-01-28 20:09:42','2021-01-28 20:09:42'),(4,'program head','2021-01-28 20:09:42','2021-01-28 20:09:42'),(5,'dean','2021-01-28 20:09:42','2021-01-28 20:09:42'),(6,'vice president','2021-01-28 20:09:42','2021-01-28 20:09:42');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `teacher_id` bigint unsigned NOT NULL,
  `course_id` bigint unsigned NOT NULL,
  `schedule` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `room` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sections_teacher_id_foreign` (`teacher_id`),
  KEY `sections_course_id_foreign` (`course_id`),
  CONSTRAINT `sections_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `sections_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,'IS - 4A',4,144,'MWF 08:00am-11:00am',' Rm. FIELD 7','2021-01-28 20:17:12','2021-01-28 20:17:12'),(2,'CS - 2A',4,214,'MF 01:00pm-02:00pm','CCS_NEW_BLDG Rm. NR5','2021-01-28 20:17:12','2021-01-28 20:17:12'),(3,'CS - 2A',4,57,'TH 07:30am-09:00am','CCS Building Rm. CL 104','2021-01-28 20:17:12','2021-01-28 20:17:12');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES ('332n0eqnBXJAPxm78M8sXtE7Ry9ddmGbrNgG3cQH',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36','YToyOntzOjY6Il90b2tlbiI7czo0MDoiZ0U0VEJvTFIxVnU3WmlDV1NNSUE3eVQwV25tUWVVS0RzNFpFWnZEbyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1611868577),('5AeV5ADuUKSshdEg2NYp6rljXB0mbpY30vgLIEsg',4,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36','YTo3OntzOjY6Il90b2tlbiI7czo0MDoiWVBDcjRHOHU0UjBBY1pmdUc1dHVqNVY4bms5S0w2WkpvRTFBaFB5VCI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjMyOiJodHRwOi8vZWxtcy50ZXN0L3RlYWNoZXIvdGFza3MvMiI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6ODoid2hlcmVhbWkiO3M6NzoidGVhY2hlciI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6NDtzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2MDoiJDJ5JDEwJGE4bkpsaVZFb1c4N1JOeUp3M1dqaS5sb2FBSG5BM2JzYUdWUWgxeklrQk0wQjVrRmhMVU1tIjt9',1611872193),('a2uhw3RoWRe8hZMX1ecBdZCFEI3vomDebCBxD8Y4',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36','YToyOntzOjY6Il90b2tlbiI7czo0MDoicDRXbjNtakJ6Z2FEcW9TS1hrVTVsUm14RHQwWENqV20yYUpHTnBTYSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1611865031),('DOztpq71rVm8z3IJaTFVjUqeXOD4txvTdHUv0Clt',100,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36','YTo3OntzOjY6Il90b2tlbiI7czo0MDoiNHhmZzFkcks2RTNVY2FXQkd4TDJvYTVJdzJ0UkJYQUdtZ0lTU2xuSCI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjMyOiJodHRwOi8vZWxtcy50ZXN0L3N0dWRlbnQvdGFza3MvMSI7fXM6NjoiX2ZsYXNoIjthOjI6e3M6Mzoib2xkIjthOjA6e31zOjM6Im5ldyI7YTowOnt9fXM6ODoid2hlcmVhbWkiO3M6Nzoic3R1ZGVudCI7czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTAwO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTAkOTJJWFVOcGtqTzByT1E1YnlNaS5ZZTRvS29FYTNSbzlsbEMvLm9nL2F0Mi51aGVXRy9pZ2kiO30=',1611865566),('KAXQyk3RSssq9sx057vekwkIGLybAEVUrpgnzuMm',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36','YToyOntzOjY6Il90b2tlbiI7czo0MDoibkR1MzdmZm9VNzU3VmhXdzdEazFVU0kxODRjT2ZzS3dRVUpuelNHayI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1611868355),('KUGlqHqQg430kNkqiUp6DhSscYa87fRsWVy7malf',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36','YToyOntzOjY6Il90b2tlbiI7czo0MDoiQXZZTUZWQzNtZGJVSzZVRVhKc2pWYXdNRVBOM1kxQllzeDJsMGxXeSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1611868561),('ugOz2pqnYA9KjBqhJPC3FIz2x58irkPfQGtrTvYe',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36','YToyOntzOjY6Il90b2tlbiI7czo0MDoiOWEzWTdTZTlTbnFDZ0NiYk9MUFpYVjNWbUkxb3c1Z2YxQ1diUUpVSiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1611865051),('UKl6UaJve4cBa8HEJynXpFXqfewXM4PRjGqDwH4P',4,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36','YTo3OntzOjY6Il90b2tlbiI7czo0MDoiVmhFMkxwRFlETU1hTzRERUhaSGhQdld3NUVxTVp3R2IzVlhESFZGMiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjM2OiJodHRwOi8vZWxtcy50ZXN0L3RlYWNoZXIvbXktd29ya2xvYWQiO31zOjg6IndoZXJlYW1pIjtzOjc6InRlYWNoZXIiO3M6NTA6ImxvZ2luX3dlYl81OWJhMzZhZGRjMmIyZjk0MDE1ODBmMDE0YzdmNThlYTRlMzA5ODlkIjtpOjQ7czoxNzoicGFzc3dvcmRfaGFzaF93ZWIiO3M6NjA6IiQyeSQxMCRhOG5KbGlWRW9XODdSTnlKdzNXamkubG9hQUhuQTNic2FHVlFoMXpJa0JNMEI1a0ZoTFVNbSI7fQ==',1611872017),('voiW39wFBSNCDqDYeLOKe94p7Zy9icaxZIArsqaU',NULL,'127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.104 Safari/537.36','YToyOntzOjY6Il90b2tlbiI7czo0MDoiZ0NEUm5iaGVKajlwWjJGWlBTQlQ0cU5nQW1yalprUGlnOTJhR2luMCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==',1611867324);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `student_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_task` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `section_id` bigint unsigned NOT NULL,
  `task_id` bigint unsigned NOT NULL,
  `isGraded` tinyint(1) NOT NULL DEFAULT '0',
  `answers` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `assessment` longtext COLLATE utf8mb4_unicode_ci,
  `score` int NOT NULL DEFAULT '0',
  `date_submitted` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_task_student_id_foreign` (`student_id`),
  KEY `student_task_section_id_foreign` (`section_id`),
  KEY `student_task_task_id_foreign` (`task_id`),
  CONSTRAINT `student_task_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`),
  CONSTRAINT `student_task_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  CONSTRAINT `student_task_task_id_foreign` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `student_task` WRITE;
/*!40000 ALTER TABLE `student_task` DISABLE KEYS */;
INSERT INTO `student_task` VALUES (2,83,1,2,1,'[{\"answer\":\"Answer1\"},{\"answer\":\"This is option 1\"},{\"answer\":\"False\"},{\"answer\":\"Lorem ipsum doler siadat alsdkts.\"},{\"answer\":\"My answer\",\"files\":[{\"name\":\"qMpBEYRJzY4UI8cLC4mCogrwQc0D7gRT33nCt1Jr.txt\",\"url\":\"tasks\\/TpmhxA36FlVpDyEYyC96db6FOgKLB1GS7pMAUwDc.txt\"},{\"name\":\"home.html\",\"url\":\"tasks\\/cXIp8OmPDaLGQVvWlKxRLIhHAfOBvXMPuxEJQPnk.html\"}]},{\"answer\":\"[\\\"Item 1\\\",\\\"Item2\\\",\\\"Item 3\\\"]\"}]','[{\"isCorrect\":false,\"score\":0},{\"isCorrect\":true,\"score\":\"5\"},{\"isCorrect\":false,\"score\":0},{\"isCorrect\":\"partial\",\"score\":15},{\"isCorrect\":\"partial\",\"score\":\"22\"},{\"isCorrect\":\"partial\",\"score\":2}]',44,'2021-01-29 04:23:55','2021-01-28 20:23:55','2021-01-28 20:23:55');
/*!40000 ALTER TABLE `student_task` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `student_teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_teacher` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `student_id` bigint unsigned NOT NULL,
  `teacher_id` bigint unsigned NOT NULL,
  `section_id` bigint unsigned NOT NULL,
  `course_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_teacher_student_id_foreign` (`student_id`),
  KEY `student_teacher_teacher_id_foreign` (`teacher_id`),
  KEY `student_teacher_section_id_foreign` (`section_id`),
  KEY `student_teacher_course_id_foreign` (`course_id`),
  CONSTRAINT `student_teacher_course_id_foreign` FOREIGN KEY (`course_id`) REFERENCES `courses` (`id`),
  CONSTRAINT `student_teacher_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`),
  CONSTRAINT `student_teacher_student_id_foreign` FOREIGN KEY (`student_id`) REFERENCES `students` (`id`),
  CONSTRAINT `student_teacher_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `student_teacher` WRITE;
/*!40000 ALTER TABLE `student_teacher` DISABLE KEYS */;
INSERT INTO `student_teacher` VALUES (1,83,4,1,144,NULL,NULL),(2,1,4,3,57,NULL,NULL),(3,84,4,3,57,NULL,NULL);
/*!40000 ALTER TABLE `student_teacher` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `students` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `college_id` bigint unsigned NOT NULL,
  `department_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `students_user_id_foreign` (`user_id`),
  KEY `students_college_id_foreign` (`college_id`),
  KEY `students_department_id_foreign` (`department_id`),
  CONSTRAINT `students_college_id_foreign` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`id`),
  CONSTRAINT `students_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `students_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (1,18,3,8,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(2,19,1,3,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(3,20,3,8,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(4,21,3,8,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(5,22,3,8,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(6,23,1,2,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(7,24,2,5,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(8,25,1,3,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(9,26,3,9,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(10,27,3,12,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(11,28,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(12,29,1,2,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(13,30,3,7,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(14,31,3,8,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(15,32,3,8,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(16,33,3,8,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(17,34,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(18,35,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(19,36,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(20,37,3,8,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(21,38,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(22,39,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(23,40,1,2,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(24,41,2,6,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(25,42,3,7,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(26,43,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(27,44,3,10,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(28,45,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(29,46,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(30,47,3,11,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(31,48,3,12,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(32,49,2,5,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(33,50,1,3,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(34,51,3,12,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(35,52,2,6,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(36,53,2,6,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(37,54,2,6,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(38,55,1,3,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(39,56,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(40,57,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(41,58,3,11,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(42,59,2,5,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(43,60,3,11,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(44,61,2,5,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(45,62,3,12,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(46,63,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(47,64,2,5,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(48,65,1,2,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(49,66,3,11,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(50,67,3,12,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(51,68,3,12,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(52,69,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(53,70,3,9,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(54,71,3,10,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(55,72,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(56,73,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(57,74,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(58,75,3,10,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(59,76,3,12,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(60,77,1,2,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(61,78,1,3,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(62,79,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(63,80,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(64,81,3,11,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(65,82,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(66,83,1,2,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(67,84,3,10,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(68,85,3,11,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(69,86,3,10,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(70,87,3,12,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(71,88,1,2,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(72,89,1,2,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(73,90,1,2,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(74,91,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(75,92,2,6,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(76,93,3,12,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(77,94,3,12,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(78,95,2,5,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(79,96,1,3,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(80,97,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(81,98,2,6,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(82,99,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(83,100,1,2,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(84,101,2,5,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(85,102,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(86,103,2,5,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(87,104,3,12,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(88,105,2,4,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(89,106,3,7,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(90,107,3,10,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(91,108,2,6,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(92,109,1,2,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(93,110,1,3,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(94,111,1,1,'2021-01-28 20:09:46','2021-01-28 20:09:46'),(95,112,2,6,'2021-01-28 20:09:47','2021-01-28 20:09:47'),(96,113,1,3,'2021-01-28 20:09:47','2021-01-28 20:09:47'),(97,114,3,9,'2021-01-28 20:09:47','2021-01-28 20:09:47'),(98,115,1,2,'2021-01-28 20:09:47','2021-01-28 20:09:47'),(99,116,3,10,'2021-01-28 20:09:47','2021-01-28 20:09:47');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `task_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_types` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `task_types` WRITE;
/*!40000 ALTER TABLE `task_types` DISABLE KEYS */;
INSERT INTO `task_types` VALUES (1,'assignment','2021-01-28 20:09:57','2021-01-28 20:09:57'),(2,'quiz','2021-01-28 20:09:57','2021-01-28 20:09:57'),(3,'activity','2021-01-28 20:09:57','2021-01-28 20:09:57'),(4,'exam','2021-01-28 20:09:57','2021-01-28 20:09:57');
/*!40000 ALTER TABLE `task_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `open` tinyint(1) NOT NULL DEFAULT '1',
  `autocorrect` tinyint(1) NOT NULL DEFAULT '0',
  `open_on` datetime DEFAULT NULL,
  `module_id` bigint unsigned NOT NULL,
  `section_id` bigint unsigned NOT NULL,
  `teacher_id` bigint unsigned NOT NULL,
  `task_type_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_score` int NOT NULL,
  `essay_rubric` text COLLATE utf8mb4_unicode_ci,
  `matchingtype_options` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `deadline` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tasks_module_id_foreign` (`module_id`),
  KEY `tasks_section_id_foreign` (`section_id`),
  KEY `tasks_teacher_id_foreign` (`teacher_id`),
  KEY `tasks_task_type_id_foreign` (`task_type_id`),
  CONSTRAINT `tasks_module_id_foreign` FOREIGN KEY (`module_id`) REFERENCES `modules` (`id`),
  CONSTRAINT `tasks_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`),
  CONSTRAINT `tasks_task_type_id_foreign` FOREIGN KEY (`task_type_id`) REFERENCES `task_types` (`id`),
  CONSTRAINT `tasks_teacher_id_foreign` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES (2,1,0,NULL,1,1,4,4,'First Exam',88,'{\"criteria\":[{\"name\":\"Structure (Spelling, Grammar, etc.)\",\"weight\":50},{\"name\":\"Content (Relevance to theme, coherence, etc.)\",\"weight\":50}],\"performance_rating\":[\"Excellent\",\"Good\",\"Satisfactory\"]}','[\"Option1\",\"Option2\",\"Option3\",\"Option4\",\"Option5\"]','[{\"files\":[],\"question\":\"What is question 1?\",\"points\":\"10\",\"options\":[],\"enumerationItems\":[],\"torf\":false,\"essay\":false,\"enumeration\":false,\"attachment\":false,\"answer\":\"Option1\",\"item_no\":1},{\"files\":[],\"question\":\"Which is question 2?\",\"points\":\"5\",\"options\":[\"This is option 1\",\"This is option 2\",\"This is option 3\"],\"enumerationItems\":[],\"torf\":false,\"essay\":false,\"enumeration\":false,\"attachment\":false,\"answer\":\"This is option 1\",\"item_no\":2},{\"files\":[],\"question\":\"This is question 3?\",\"points\":\"10\",\"options\":[\"True\",\"False\"],\"enumerationItems\":[],\"torf\":true,\"essay\":false,\"enumeration\":false,\"attachment\":false,\"answer\":\"True\",\"item_no\":3},{\"files\":[],\"question\":\"This is question 4?\",\"points\":\"30\",\"options\":[],\"enumerationItems\":[],\"torf\":false,\"essay\":true,\"enumeration\":false,\"attachment\":false,\"item_no\":4},{\"files\":[],\"question\":\"This is question 5?\",\"points\":\"30\",\"options\":[],\"enumerationItems\":[],\"torf\":false,\"essay\":false,\"enumeration\":false,\"attachment\":true,\"item_no\":5},{\"files\":[],\"question\":\"This is question 6?\",\"points\":\"1\",\"options\":[],\"enumerationItems\":[\"Item 1\",\"Item 2\",\"Item 3\"],\"torf\":false,\"essay\":false,\"enumeration\":true,\"attachment\":false,\"item_no\":6}]','2021-01-31 04:23:55','2021-01-28 20:23:55','2021-01-28 20:23:55');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teachers` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `college_id` bigint unsigned NOT NULL,
  `department_id` bigint unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teachers_user_id_foreign` (`user_id`),
  KEY `teachers_college_id_foreign` (`college_id`),
  KEY `teachers_department_id_foreign` (`department_id`),
  CONSTRAINT `teachers_college_id_foreign` FOREIGN KEY (`college_id`) REFERENCES `colleges` (`id`),
  CONSTRAINT `teachers_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `teachers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES (1,1,2,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(2,2,2,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(3,3,2,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(4,4,2,4,'2021-01-28 20:09:43','2021-01-28 22:12:37'),(5,5,2,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(6,6,2,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(7,7,2,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(8,8,2,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(9,9,2,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(10,10,2,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(11,11,2,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(12,12,2,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(13,13,2,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(14,14,2,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(15,15,2,NULL,'2021-01-28 20:09:44','2021-01-28 22:11:15'),(16,16,2,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(17,17,2,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `todos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `todos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned NOT NULL,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `completed` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `todos_user_id_foreign` (`user_id`),
  CONSTRAINT `todos_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `todos` WRITE;
/*!40000 ALTER TABLE `todos` DISABLE KEYS */;
/*!40000 ALTER TABLE `todos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `campus_id` bigint unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_campus_id_foreign` (`campus_id`),
  CONSTRAINT `users_campus_id_foreign` FOREIGN KEY (`campus_id`) REFERENCES `campuses` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,1,'Cecilia E. Gener','cecilia.gener@sksu.edu.ph',NULL,'$2y$10$NDR8SJ7ip5BjCbKwkEWZP.fubJ6jNO0b2AaGh2kMffxh23h1Q1Qvy',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(2,1,'Elmer C. Buenavides','elmer.buenavides@sksu.edu.ph',NULL,'$2y$10$KowzebxaRlKcsEI.BKUHD.3WUH/hh9ojRM6IYljDkK23ZnrjH0Ipq',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(3,1,'Mary Grace L. Perocho','marygrace.perocho@sksu.edu.ph',NULL,'$2y$10$w4GlgXs0FPqKfWbaOdCN4Oz3V/pP7DDtSj/T6VP0R5vzNxHOY0M0S',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(4,1,'Cyrus B. Rael','cyrus.rael@sksu.edu.ph',NULL,'$2y$10$a8nJliVEoW87RNyJw3Wji.loaAHnA3bsaGVQh1zIkBM0B5kFhLUMm',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(5,1,'Roma Amor C. Castromayor','romaamor.castromayor@sksu.edu.ph',NULL,'$2y$10$DtqTwdKxW7KrnTzSe5F9M.1U1hhb1Bl5altdAnjiaPgZQqDxAEzvG',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(6,1,'Elbren O. Antonio','elbren.antonio@sksu.edu.ph',NULL,'$2y$10$kj1FRXAnlvs3hFbzAjYsdO87KkVyymUPpqKz3guWYMZqnmHGdNiUu',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(7,1,'Velessa Dulin','velessa.dulin@sksu.edu.ph',NULL,'$2y$10$6vqt/FaLX5U7idGthDAg1usDEovNrxA/bPbQxzDMcD/sVhETPVJQS',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(8,1,'Kyrene L. Dizon','kyrene.dizon@sksu.edu.ph',NULL,'$2y$10$OAtbCL1Gthga5YZPNPhTXegKGrPLVDSoYK/pclHloIPixrWc3g192',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(9,1,'Joe H. Selayro','joe.selayro@sksu.edu.ph',NULL,'$2y$10$RCq2S0r6jSo/YkYL9HWyieVB.JEqmHKlNFhgpbRpHjbsarEOKZaZu',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(10,1,'Mark Ian Orcajada','markian.orcajada@sksu.edu.ph',NULL,'$2y$10$TSOpRxjI2E0A/QfGmPtmhuW.JcS1g.jPMXFupttqfNu8IN6jAiySm',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:43','2021-01-28 20:09:43'),(11,1,'Alexis D. Apresto','alexis.apresto@sksu.edu.ph',NULL,'$2y$10$OnZIkkJeQf8OG6dJYDKMyuD2TNOCNAn0saaJ6dY6KidTrQTRlSL66',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(12,1,'Florlyn Remegio','florlyn.remegio@sksu.edu.ph',NULL,'$2y$10$SutCsTKECtt5v.cj.m1NOelANAUNvMwrubfMpJr3vP2bAztqPg0SO',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(13,1,'Ivy Lynn Madriaga','ivylynn.madriaga@sksu.edu.ph',NULL,'$2y$10$yWp6mA2Y9coY9OeZTbbP6OgHW4creHq4XDuKnTex.tdmfbV4Dhvim',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(14,1,'Esnehara Bagundang','esnehara.bagundang@sksu.edu.ph',NULL,'$2y$10$KwA5clXxiOYR1Ax5JCJ0WuPpDjbq69E64RR/o.ycNlYDg9O5Ke5yC',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(15,1,'Kristine Mae Ampas','kristinemaeampas@sksu.edu.ph',NULL,'$2y$10$JGVoiIytejuhvVJiJ6lkSuwBB7D/kdE8oliN4iJlCtJFuEW7XLqR2',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(16,1,'Edmarlyn Porras','edmarlyn.porras@sksu.edu.ph',NULL,'$2y$10$O72hDvJZVt6pE06zenVtTejjgZhq0Bi1hW06lEebQi0ycCVGasLX.',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(17,1,'Cerilo Rubin','cerilorubin@sksu.edu.ph',NULL,'$2y$10$fT2v89MeSo2ex7CHDZMDNeH7YUZsrd/f5YcyTzPYY/YKmL1BMO7lW',NULL,NULL,NULL,NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(18,1,'Lucinda Considine Jr.','1018@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'HyKDJq8PGL',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(19,1,'Prof. Abdiel Dare IV','1019@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'dW9F1Oh4TQ',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(20,1,'Rosie Nicolas','1020@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'ur3ZPZMrsX',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(21,1,'Dr. Tommie Pacocha II','1021@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'CGMhrlKpCc',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(22,1,'Prof. Thad Morar','1022@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'oY6NT5WXU9',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(23,1,'Ms. Vickie Koelpin I','1023@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'cSxHWJ6DlU',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(24,1,'Austen Champlin','1024@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'je2dsOHYqm',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(25,1,'Kathleen Heidenreich','1025@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'oeFuIsvkmH',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(26,1,'Adrian Carroll','1026@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'PBIQ5i4HHQ',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(27,1,'Prof. Marty Osinski','1027@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'fJeYekb1Hx',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(28,1,'Paxton Hackett','1028@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'b6FMnfet1V',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(29,1,'Gene Koss','1029@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'PCFKP1PWdx',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(30,1,'Aubrey Homenick IV','1030@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'sz4IthvdTg',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(31,1,'Taryn Mitchell I','1031@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'OJDEDCCZF5',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(32,1,'Kris VonRueden','1032@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'QQsexnA9oh',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(33,1,'Mr. Sammie Nolan DVM','1033@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'iDswovTmPK',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(34,1,'Dr. Nasir Boyer III','1034@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'ASSqMbK0ss',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(35,1,'Mr. Rodrigo Towne IV','1035@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'kEffVgIf7b',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(36,1,'Jocelyn Marks','1036@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'0Z8j0iuq8L',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(37,1,'Cassidy Shields','1037@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'R0kxlJHvYw',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(38,1,'Cooper Halvorson','1038@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'PPxsy6WEW4',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(39,1,'Mrs. Alessandra Harris I','1039@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'mohJgY3gG4',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(40,1,'Kale Ullrich','1040@gmail.com','2021-01-28 20:09:44','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'4swxIhQ46r',NULL,NULL,'2021-01-28 20:09:44','2021-01-28 20:09:44'),(41,1,'Javier Pacocha','1041@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'sPuv0gFXsj',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(42,1,'Mr. Scottie Kunde DVM','1042@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'uxqBzD7SXR',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(43,1,'Abel Bosco','1043@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'8r2EYa9JC0',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(44,1,'Emory Barton','1044@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'PJW6gSHpZc',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(45,1,'Reece Rowe I','1045@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'6MW4PusfHv',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(46,1,'Aubrey Rowe','1046@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'hVPCAsQFiD',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(47,1,'Ms. Anita Padberg Sr.','1047@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'5jvcU91Dec',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(48,1,'Mollie Sporer III','1048@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'Jz8rxZlbEd',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(49,1,'Dr. Bo Goyette III','1049@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'y6oLWmW2Gw',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(50,1,'Katlynn Roob','1050@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'4DXPUfT7eY',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(51,1,'Ms. Elisa Keeling III','1051@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'MzzIz0ode5',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(52,1,'Bette Jakubowski','1052@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'Br0RzqnqGX',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(53,1,'Lucy Romaguera IV','1053@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'XP4iyniO0A',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(54,1,'Danny Bruen','1054@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'oiME1PxgK0',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(55,1,'Mr. Zackary Gutkowski','1055@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'iiNEiIMyng',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(56,1,'Johnpaul Pfannerstill Jr.','1056@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'VzZTDCOAWJ',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(57,1,'Dr. Garfield Satterfield III','1057@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'U2U8nmPMYi',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(58,1,'Agustina Marquardt','1058@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'mP42SDmmtP',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(59,1,'Miss Kaylee Koepp','1059@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'ZHOwyRqy0L',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(60,1,'Marcellus Tremblay','1060@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'SpmbVt6et8',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(61,1,'Reina Zboncak','1061@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'qma0gseqpm',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(62,1,'Johnson Wunsch','1062@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'Oa5hCPGYY2',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(63,1,'Gertrude Schaefer','1063@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'IK0SmmUJWf',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(64,1,'Shayna Beer','1064@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'GS36ieuleu',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(65,1,'Durward Johnson','1065@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'fnjvL6fqft',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(66,1,'Tracy Gislason','1066@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'2FtX9rut4V',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(67,1,'Dr. Gideon Skiles','1067@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'e0N4JdvRZR',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(68,1,'Mr. Jamison Kuhic','1068@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'fAi0PqDjjF',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(69,1,'Dr. Afton Bins DVM','1069@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'RlQRQoOiQ8',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(70,1,'Letitia Feest','1070@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'Rt94glnVpf',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(71,1,'Mallie Von DVM','1071@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'YUWU6trMS4',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(72,1,'Andreane Heaney','1072@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'jbkXz1Sttl',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(73,1,'Dr. Rae Gleason','1073@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'jzTX1FJ75b',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(74,1,'Sylvan Mante','1074@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'nyzykhy2OC',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(75,1,'Miss Andreanne McLaughlin III','1075@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'ZxUvtBRIPA',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(76,1,'Keanu Powlowski','1076@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'kmTHqPuRRQ',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(77,1,'Felipe Stark','1077@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'dIGcZzVxVv',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(78,1,'Zola Harris','1078@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'CaFjwGcdsY',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(79,1,'Marcelina Wolf','1079@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'pPegkINqYv',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(80,1,'Hal Rau','1080@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'0vBPCnUoiH',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(81,1,'Sharon Nienow','1081@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'s6NiGUOU6z',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(82,1,'Kaley Davis','1082@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'7XwQmzaPHi',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(83,1,'Rasheed Kreiger','1083@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'6rX2b1Eodo',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(84,1,'Zane Wintheiser','1084@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'xkKLaEO6G7',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(85,1,'Nina Boehm II','1085@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'tkCGiH0tah',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(86,1,'Roel Okuneva','1086@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'hhCr7b0sB7',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(87,1,'Otho Bode','1087@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'Km50qM8nr5',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(88,1,'Abbigail Tremblay','1088@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'engU1Esywj',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(89,1,'Mr. Jed Rodriguez','1089@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'ujsfoLDNUe',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(90,1,'Taya Swaniawski','1090@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'gzzKCDnn8t',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(91,1,'Emerald Beier','1091@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'zIgA2P26jZ',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(92,1,'Kendrick Hyatt','1092@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'ny0qJPosZt',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(93,1,'Arturo Parker','1093@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'zUgKJBZ9UC',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(94,1,'Dax Walker','1094@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'V0YBcjzyHe',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(95,1,'Prof. Arthur Boyer','1095@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'gdk1hxXrDc',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(96,1,'Faustino Haag','1096@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'0oQNkLr08s',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(97,1,'Mr. Hershel Buckridge','1097@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'pTMd1k4od2',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(98,1,'Caleigh Jast','1098@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'JmAJo499kf',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(99,1,'Javon Hilpert','1099@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'8A0AEjrtjP',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(100,1,'Nikita Wunsch','1100@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'rLUwKMzmma',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(101,1,'Mr. Trent Ferry','1101@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'9v0dQWXx11',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(102,1,'Miss Amie Brown','1102@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'j3VM32dhhH',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(103,1,'Jules Runte','1103@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'5GXZb4JqDJ',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(104,1,'Albina Beer','1104@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'gknKWwwHgY',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(105,1,'Erik Cummings III','1105@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'naY7RyxkMR',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(106,1,'Juana Tillman','1106@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'TVjZcuI3qB',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(107,1,'Alvah Pfeffer V','1107@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'MyVWZa0ml6',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(108,1,'Blaise Turner','1108@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'kH9TGs1tvh',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(109,1,'Amy Lindgren','1109@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'w4KZPE7anh',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(110,1,'Prof. Julien Hane','1110@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'NV14w0orus',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(111,1,'Dr. Orion Harris IV','1111@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'KjBpQKlMYS',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(112,1,'Fatima Ruecker Jr.','1112@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'cXE2SC6YsR',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(113,1,'Prof. Kelly Borer','1113@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'1s9U2esAJ0',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(114,1,'Robb Mitchell','1114@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'qcy8OhVVk9',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(115,1,'Preston Deckow','1115@gmail.com','2021-01-28 20:09:45','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'OTknJGYas1',NULL,NULL,'2021-01-28 20:09:45','2021-01-28 20:09:45'),(116,1,'Stephon McLaughlin','1116@gmail.com','2021-01-28 20:09:46','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',NULL,NULL,'yZr3MHNDyg',NULL,NULL,'2021-01-28 20:09:46','2021-01-28 20:09:46');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `videorooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `videorooms` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `section_id` bigint unsigned NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `videorooms_section_id_foreign` (`section_id`),
  CONSTRAINT `videorooms_section_id_foreign` FOREIGN KEY (`section_id`) REFERENCES `sections` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `videorooms` WRITE;
/*!40000 ALTER TABLE `videorooms` DISABLE KEYS */;
/*!40000 ALTER TABLE `videorooms` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

