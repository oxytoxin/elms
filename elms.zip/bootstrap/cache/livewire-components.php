<?php return array (
  'create-course' => 'App\\Http\\Livewire\\CreateCourse',
  'event-creator' => 'App\\Http\\Livewire\\EventCreator',
  'head-courses-page' => 'App\\Http\\Livewire\\HeadCoursesPage',
  'layouts.sidelist' => 'App\\Http\\Livewire\\Layouts\\Sidelist',
  'task-maker' => 'App\\Http\\Livewire\\TaskMaker',
  'task-taker' => 'App\\Http\\Livewire\\TaskTaker',
  'teacher-courses-page' => 'App\\Http\\Livewire\\TeacherCoursesPage',
  'teacher-tasklist' => 'App\\Http\\Livewire\\TeacherTasklist',
);