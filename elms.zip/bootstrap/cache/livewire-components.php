<?php return array (
  'create-course' => 'App\\Http\\Livewire\\CreateCourse',
  'head-courses-page' => 'App\\Http\\Livewire\\HeadCoursesPage',
  'teacher-courses-page' => 'App\\Http\\Livewire\\TeacherCoursesPage',
);