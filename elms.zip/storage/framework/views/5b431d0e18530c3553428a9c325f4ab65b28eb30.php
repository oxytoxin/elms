<!DOCTYPE html>
<html oncontextmenu="return false" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'ELMS')); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fa-min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('icofont/icofont.min.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.6.0/dist/alpine.js" defer></script>
</head>

<body class="w-full overflow-x-hidden font-sans antialiased">
    <div class="flex min-h-screen bg-gray-100">

        <aside class="hidden w-1/6 md:block bg-primary-600">
            <?php echo $__env->make('includes.head.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </aside>

        <!-- Page Content -->
        <article class="flex-1">
            <?php echo $__env->yieldContent('content'); ?>
        </article>
    </div>

    <?php echo $__env->yieldPushContent('modals'); ?>

    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views/layouts/head.blade.php ENDPATH**/ ?>