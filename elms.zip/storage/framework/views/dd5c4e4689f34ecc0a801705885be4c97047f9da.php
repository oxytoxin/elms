
<?php $__env->startSection('content'); ?>
<div class="px-5">
    <div class="">
        <div>
            <h1 class="text-2xl font-semibold">COURSE MANAGER</h1>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-course')->html();
} elseif ($_instance->childHasBeenRendered('Vwg3Ttl')) {
    $componentId = $_instance->getRenderedChildComponentId('Vwg3Ttl');
    $componentTag = $_instance->getRenderedChildComponentTagName('Vwg3Ttl');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Vwg3Ttl');
} else {
    $response = \Livewire\Livewire::mount('create-course');
    $html = $response->html();
    $_instance->logRenderedChild('Vwg3Ttl', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.head.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\pages\head\courses\create.blade.php ENDPATH**/ ?>