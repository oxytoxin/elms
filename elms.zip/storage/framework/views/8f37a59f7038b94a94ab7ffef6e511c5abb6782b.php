<nav class="flex items-center justify-between w-full">
    <div class="flex items-center left">
        <a href="#"><i class="text-2xl icofont-arrow-left"></i></a>
        <h1 class="text-xl">Network Technology 1 - SY1920-2T</h1>
    </div>
    <div class="flex items-center right">
        <a href="/" class="text-blue-600">Home</a>
        <i class="icofont-long-arrow-right"></i>
        <a href="#">Network Technology 1 - SY1920-2T</a>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\includes\student\nav.blade.php ENDPATH**/ ?>