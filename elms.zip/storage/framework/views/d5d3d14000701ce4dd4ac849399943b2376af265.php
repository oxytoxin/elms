
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.head.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="p-3">
    <div class="flex min-h-screen">
        <div class="w-5/6 mx-4">
            <h1 class="text-2xl font-semibold">HOME</h1>
            <div class="grid gap-2 p-2 md:grid-cols-4">
                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="w-full overflow-hidden h-80">
                    <div class="h-1/2"><img src="<?php echo e(asset('img/course.jpg')); ?>" class="object-cover w-full h-full"
                            alt="course"></div>
                    <div class="p-2 text-white h-4/12 bg-secondary-500">
                        <h1 class="text-sm text-center"><?php echo e($course->name); ?></h1>
                        <h1 class="font-semibold text-center text-orange-500"><?php echo e($course->code); ?></h1>
                    </div>
                    <div class="h-2/12">
                        <a href="<?php echo e(route('head.course',['course'=>$course->id])); ?>"
                            class="flex items-center justify-center w-full h-full p-1 text-white hover:text-black bg-primary-600">
                            View Course
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h1>No Course Found</h1>
                <?php endif; ?>
            </div>
        </div>
        <?php echo $__env->make('includes.head.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\pages\head\index.blade.php ENDPATH**/ ?>