<div x-data="{showAdd:<?php if ((object) ('showAdd') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showAdd'->value()); ?>')<?php echo e('showAdd'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showAdd'); ?>') <?php endif; ?>}">
    <div class="bg-white rounded-sm shadow-md card">
        <div class="flex justify-between px-3 py-1 border-b border-gray-500 title">
            <h1 class="text-sm font-semibold"><i wire:loading class="mr-2 fas fa-spinner fa-spin"></i>To Do</h1>
            <button @click="showAdd = true" class="focus:outline-none hover:text-primary-600"><i class="icofont-plus"></i></button>
        </div>
        <div @click.away="showAdd = !showAdd" x-cloak x-show.transition="showAdd" class="flex p-2">
            <input wire:model.defer="todo" autofocus type="text" class="w-10/12 text-xs form-input">
            <button wire:click="addTodo" class="px-2 mx-1 text-lg text-white rounded-lg focus:outline-none bg-primary-500 hover:bg-primary-600"><i class="icofont-check"></i></button>
        </div>
        <div class="px-2">
            <?php $__errorArgs = ['todo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <h1 class="text-xs italic text-red-600"><?php echo e($message); ?></h1>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="p-2 text-sm min-h-16 content">
            <ul>
                <?php $__empty_1 = true; $__currentLoopData = $todos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $todo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li class="flex items-center px-1 my-1 truncate">
                    <button class="focus:outline-none" wire:click="markAsDone(<?php echo e($todo->id); ?>)">
                        <i class="mr-1 text-lg cursor-pointer icofont-check-circled hover:text-primary-500"></i>
                    </button>
                    <button wire:click="removeTodo(<?php echo e($todo->id); ?>)" class="mx-1 text-red-600 rounded-lg text-md focus:outline-none"><i class="icofont-trash"></i></button><span class="cursor-pointer <?php echo e($todo->completed ? 'line-through' : ''); ?>" title="<?php echo e($todo->content); ?>"><?php echo e($todo->content); ?></span>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li>Create your first to-do!</li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
    <?php if(auth()->user()->isStudent()): ?>
    <div class="mt-5 bg-white rounded-sm shadow-md card">
        <div class="flex justify-between px-3 py-1 border-b border-gray-500 title">
            <h1 class="text-sm font-semibold">Upcoming Tasks</h1>
        </div>
        <div class="p-2 min-h-16 content">
            <ul>
                <?php $__empty_1 = true; $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upcome): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li wire:key="upcoming_<?php echo e($upcome->id); ?>" title="<?php echo e($upcome->name); ?>" class="text-xs truncate">
                    <i class="mr-1 text-lg icofont-notepad"></i><a href="<?php echo e(route('student.task',['task'=>$upcome->id])); ?>" class="truncate hover:underline"><?php echo e($upcome->name); ?></a>
                    <h1 class="text-xs text-right text-red-600">(Due: <span class="font-semibold"><?php echo e($upcome->deadline->format('h:i A-M d, Y')); ?></span> )</h1>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="text-xs"> Woohoo! No upcoming tasks.
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>
    <div class="mt-5 bg-white rounded-sm shadow-md card">
        <div class="flex justify-between px-3 py-1 border-b border-gray-500 title">
            <h1 class="text-sm font-semibold">Announcements</h1>
        </div>
        <div class="p-2 min-h-16 content">
            <ul class="text-xs">
                <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li title="<?php echo e($event->title); ?>" class="p-1 truncate">
                    <i class="mr-1 text-lg text-red-600 icofont-alarm"></i><a href="<?php echo e($event->url); ?>"><?php echo e($event->title); ?></a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li class="p-1">
                    <i class="text-red-600 icofont-alarm"></i>No announcements.
                </li>
                <?php endif; ?>
                <?php if(count($events)): ?>
                <li class="p-1 font-semibold text-center truncate hover:bg-primary-500">
                   <a href="<?php echo e(\Request()->route()->getPrefix() .'/calendar'); ?>">SEE ALL</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\livewire\layouts\sidelist.blade.php ENDPATH**/ ?>