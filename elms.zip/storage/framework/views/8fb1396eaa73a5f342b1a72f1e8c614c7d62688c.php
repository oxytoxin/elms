<div class="z-20 px-4">
    <div class="m-2">
        <h1 class="text-2xl font-semibold">Gradebook</h1>
        <div>
            <h1 class="text-xl font-semibold">For Course:</h1>
            <i class="mr-4 text-xl fas fa-spin fa-spinner text-primary-600" wire:loading></i><select wire:change="updateCourse" wire:model="course_id" class="truncate form-select" name="course_select" id="course_select">
                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option value="0" selected disabled hidden>No Courses Found.</option>
                <?php endif; ?>
            </select>
            <button onclick="clearSelections()" class="p-3 text-xs font-bold text-white uppercase rounded-lg hover:bg-primary-600 bg-primary-500">Clear highlighted</button>
        </div>
    </div>
    <div class="max-h-screen overflow-auto">
        <table id="table_id" class="inline-block m-2 text-center bg-gray-700 border-collapse table-fixed">
            <thead class="border">
                    <tr class="h-8">
                        <th class="sticky top-0 left-0 z-30 bg-green-400 border" rowspan="2">Student</th>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="sticky top-0 z-20 uppercase bg-green-400 border min-w-40" colspan="<?php echo e($task->count()); ?>"><?php echo e(App\Models\TaskType::find($type)->name); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <tr>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td data-column="<?php echo e($k); ?>" class="sticky z-20 bg-green-400 border cursor-pointer top-8 score hover:bg-green-400"><a title="<?php echo e($t->name); ?>" class="w-full" href="<?php echo e(route('teacher.task',['task' => $t->id])); ?>"><h1><?php echo e($k+1); ?></h1></a></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
            </thead>
                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $students->sortBy('user.name'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="z-20 bg-white hover:bg-primary-500">
                        <th scope="row" class="z-10 sticky bg-white name-header max-w-32 md:max-w-96 md:break-normal truncate <?php echo e("row$student->id"); ?> left-0 px-3 whitespace-no-wrap border cursor-pointer hover:bg-primary-500"><?php echo e($student->user->name); ?></th>
                        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td class="px-8 py-4 border <?php echo e("row$student->id"); ?>">
                            <?php if($student->task_status($t->id) == 'ungraded'): ?>
                            <i class="text-xl text-yellow-300 icofont-question-circle"></i>
                            <?php else: ?>
                                <?php if($student->task_status($t->id)): ?>
                                <?php echo e($student->task_status($t->id)); ?>

                                <?php else: ?>
                                <i class="text-xl text-red-600 icofont-exclamation-circle"></i>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                    <?php endif; ?>
                </tbody>
        </table>
</div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
            function clearSelections() {
                document.querySelectorAll('.selected-row').forEach(e=>{
                    e.classList.remove('selected-row');
                })
            }
            document.querySelectorAll(".name-header").forEach(e=>{
                 e.addEventListener('click',l=>{
                     clearSelections();
                    l.target.parentElement.classList.add('selected-row')
                    e.classList.add('selected-row')
                 })

            })
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.teacher.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\livewire\teacher\gradebook.blade.php ENDPATH**/ ?>