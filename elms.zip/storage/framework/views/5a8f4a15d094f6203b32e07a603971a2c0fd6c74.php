
<?php $__env->startSection('content'); ?>
<div class="px-5" x-data="{showEventCreator:false}">
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('event-creator')->html();
} elseif ($_instance->childHasBeenRendered('vPdGTOK')) {
    $componentId = $_instance->getRenderedChildComponentId('vPdGTOK');
    $componentTag = $_instance->getRenderedChildComponentTagName('vPdGTOK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vPdGTOK');
} else {
    $response = \Livewire\Livewire::mount('event-creator');
    $html = $response->html();
    $_instance->logRenderedChild('vPdGTOK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <h1 class="text-2xl font-semibold">Calendar of Events</h1>
    <button @click="showEventCreator = true" class="p-2 text-white rounded-md bg-primary-500"><i class="mr-2 icofont-plus"></i>Create an Event</button>
    <div class="flex overflow-x-auto">
        <div id='calendar' class="w-full mt-5 overflow-x-auto"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.student.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.3.2/main.min.js"></script>
<script>

    document.addEventListener('DOMContentLoaded', function() {
      var calendarEl = document.getElementById('calendar');
      var calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'dayGridMonth,timeGridDay'
        },
        droppable:true,
        events: <?php echo json_encode($events->toArray()); ?>


      });
      calendar.render();
    });
    window.addEventListener('event-created',()=>{
        location.reload()
    })
  </script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/fullcalendar@5.3.2/main.min.css">
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\pages\student\calendar.blade.php ENDPATH**/ ?>