
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.teacher.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="p-3">
    <div class="flex min-h-screen">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('teacher-courses-page',['course'=>$course])->html();
} elseif ($_instance->childHasBeenRendered('ck0wRlZ')) {
    $componentId = $_instance->getRenderedChildComponentId('ck0wRlZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('ck0wRlZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ck0wRlZ');
} else {
    $response = \Livewire\Livewire::mount('teacher-courses-page',['course'=>$course]);
    $html = $response->html();
    $_instance->logRenderedChild('ck0wRlZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php echo $__env->make('includes.teacher.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views/pages/teacher/courses/course.blade.php ENDPATH**/ ?>