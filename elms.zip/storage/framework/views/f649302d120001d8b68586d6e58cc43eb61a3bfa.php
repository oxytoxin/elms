
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.head.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="p-3">
    <div class="flex min-h-screen">
        <div class="w-full mx-4 md:w-5/6">
            <h1 class="text-2xl font-semibold"><?php echo e($file->fileable->name ? $file->fileable->name : $file->fileable->title); ?> | <?php echo e($file->name); ?></h1>
            <iframe src="https://docs.google.com/file/d/<?php echo e($file->google_id); ?>/preview" frameborder="2"
                class="w-full min-h-halfscreen md:min-h-screen"></iframe>
        </div>
        <?php echo $__env->make('includes.head.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views/pages/head/preview.blade.php ENDPATH**/ ?>