
<?php $__env->startSection('content'); ?>
<div class="px-5">
    <div class="flex">
        <div class="w-full mx-4">
            <h1 class="text-2xl font-semibold"><?php echo e($file->fileable->name ? $file->fileable->name : $file->fileable->title); ?> | <?php echo e($file->name); ?></h1>
            <iframe src="https://docs.google.com/file/d/<?php echo e($file->google_id); ?>/preview" frameborder="2"
                class="w-full min-h-halfscreen md:min-h-screen"></iframe>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.teacher.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\pages\teacher\preview.blade.php ENDPATH**/ ?>