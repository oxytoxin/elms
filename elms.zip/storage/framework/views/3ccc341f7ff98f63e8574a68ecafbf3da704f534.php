<div class="p-5">
    <h1 class="px-5 text-2xl font-semibold uppercase"><?php echo e($task->task_type->name); ?></h1>
    <h1 class="px-5 text-xl italic font-semibold uppercase"><span class="text-orange-500"><?php echo e($task->module->name); ?></span> | <?php echo e($task->name); ?></h1>
<?php $__currentLoopData = $task_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="p-2 mx-5 mt-3 border border-gray-700 rounded-lg shadow-lg">
        <h1 class="text-orange-500 underline">(<?php echo e($item['points']); ?> pt/s.) Question <?php echo e($item['item_no']); ?>.</h1>
        <h1><?php echo e($item['question']); ?></h1>
        <?php if($item['files']): ?>
        <div class="flex justify-center my-3">
            <?php $__currentLoopData = $item['files']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex flex-col items-center">
            <a target="blank" href="<?php echo e(asset('storage'.'/'.$file['url'])); ?>" class="text-sm italic underline text-primary-500">View Attachment: <?php echo e($file['name']); ?></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <?php $__empty_1 = true; $__currentLoopData = $item['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div>
            <input type="radio" wire:model="answers.item_<?php echo e($key); ?>" id="answer_<?php echo e($item['item_no']); ?>_<?php echo e($option); ?>" name="answer_<?php echo e($item['item_no']); ?>" value="<?php echo e($option); ?>" class="form-radio">
            <label for="answer_<?php echo e($item['item_no']); ?>_<?php echo e($option); ?>"><?php echo e($option); ?></label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <br>
        <label class="text-xs font-semibold uppercase" for="answer_<?php echo e($key); ?>_files">Add Attachment</label>
        <input type="file" name="answer_<?php echo e($key); ?>_files" id="answer_<?php echo e($key); ?>_files" multiple class="w-full my-2 form-input">
        <textarea wire:key="item_<?php echo e($key); ?>_textarea" placeholder="Your answer..." wire:model="answers.item_<?php echo e($key); ?>" cols="30" rows="5" class="w-full border-2 border-gray-700 form-textarea"></textarea>
    <?php endif; ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<button wire:click.prevent="submitAnswers" class="float-right p-2 mx-5 mt-3 font-semibold text-white hover:text-primary-600 bg-primary-500">Submit Answers</button>
</div>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.student.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views/livewire/task-taker.blade.php ENDPATH**/ ?>