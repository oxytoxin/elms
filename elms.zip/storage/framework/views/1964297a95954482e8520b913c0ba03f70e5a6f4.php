
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.head.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="p-3">
    <div class="flex min-h-screen">
        <div class="w-5/6 mx-4">
            <h1 class="text-2xl font-semibold">COURSE MANAGER</h1>
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('create-course')->html();
} elseif ($_instance->childHasBeenRendered('UZ4j9lO')) {
    $componentId = $_instance->getRenderedChildComponentId('UZ4j9lO');
    $componentTag = $_instance->getRenderedChildComponentTagName('UZ4j9lO');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UZ4j9lO');
} else {
    $response = \Livewire\Livewire::mount('create-course');
    $html = $response->html();
    $_instance->logRenderedChild('UZ4j9lO', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        </div>
        <?php echo $__env->make('includes.head.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views/pages/head/courses/create.blade.php ENDPATH**/ ?>