<div class="w-5/6 px-2 mx-4">
    <h1 class="text-xl font-semibold"><?php echo e($course->name); ?><i wire:loading wire:target="enrolFaculty"
            class="fa fa-spinner fa-spin"></i></h1>
    <div class="box-border flex text-lg text-gray-300 border-2 border-black">
        <a href="#" wire:click="$set('tab','faculty')"
            class="flex items-center justify-center w-1/2 <?php echo e($tab == 'faculty' ?  'bg-primary-500 text-gray-700' : ''); ?>">
            <div class="font-bold text-center uppercase hover:text-gray-700">ENROL FACULTY</div>
        </a>
        <a href="#" wire:click="$set('tab','modules')"
            class="flex items-center justify-center w-1/2 <?php echo e($tab == 'modules' ?  'bg-primary-500 text-gray-700' : ''); ?>">
            <div class="font-bold text-center uppercase hover:text-gray-700">UPLOAD MODULE RESOURCES</div>
        </a>
    </div>
    <?php if($tab == 'faculty'): ?>
    <div class="mt-2">
        <form wire:submit.prevent="enrolFaculty">
            <?php echo csrf_field(); ?>
            <label for="email">Faculty Email</label>
            <div class="italic text-green-400">
                <?php if(session()->has('message')): ?>
                <?php echo e(session('message')); ?>

                <?php endif; ?>
            </div>
            <div class="flex items-center mt-2">
                <input type="email" class="flex-1 block form-input" placeholder="user@email.com" autocomplete="off"
                    autofocus name="email" wire:model.defer="email">
                <button class="p-2 ml-2 text-white rounded-lg hover:text-black focus:outline-none bg-primary-500">Enroll
                    Faculty</button>
            </div>
        </form>
    </div>
    <h1 class="my-2 font-bold">Course Faculty List</h1>
    <table class="table w-full border-2 border-collapse border-gray-600">
        <thead class="">
            <th class="border-2 border-gray-600">Name</th>
            <th class="border-2 border-gray-600">Email</th>
        </thead>
        <tbody class="text-center">
            <?php $__empty_1 = true; $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="border-2 border-gray-600"><?php echo e($teacher->user->name); ?></td>
                <td class="border-2 border-gray-600"><?php echo e($teacher->user->email); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="2" class="border-2 border-gray-600">No faculty member found on this course.</td>
            </tr>
            <?php endif; ?>

        </tbody>
    </table>
    <?php endif; ?>
    <?php if($tab == 'modules'): ?>
    <div class="mt-2">
        <form wire:submit.prevent="addModule" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <label class="font-semibold" for="title">Module Title<i wire:loading wire:target="addModule"
                    class="fa fa-spinner fa-spin"></i></label>
            <input wire:model="moduleName" type="text" class="flex-1 block w-full form-input" autocomplete="off"
                placeholder="Module Title" autofocus name="moduleName">
            <?php $__errorArgs = ['moduleName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="flex items-center mt-2">
                <input type="file" wire:model="module" class="flex-1 block form-input" autocomplete="off" autofocus
                    id="file<?php echo e($fileId); ?>" name="module">
                <?php $__errorArgs = ['module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button wire:target="module" wire:loading.remove
                    class="p-2 ml-2 text-white rounded-lg hover:text-black focus:outline-none bg-primary-500">Upload
                    Module</button>
            </div>
        </form>
    </div>

    <div wire:target="module" wire:loading>
        <h1 class="italic font-semibold text-green-400">Uploading Module. Please
            wait...<i class="fa fa-spinner fa-spin"></i></h1>
    </div>
    <div class="italic text-green-400">
        <?php if(session()->has('message')): ?>
        <?php echo e(session('message')); ?>

        <?php endif; ?>
    </div>
    <h1 class="my-2 font-bold">Course Module List</h1>
    <table class="table w-full border-2 border-collapse border-gray-600 table-fixed">
        <thead class="">
            <th class="border-2 border-gray-600">Title</th>
            <th class="border-2 border-gray-600">Date Added</th>
        </thead>
        <tbody class="text-center">
            <?php $__empty_1 = true; $__currentLoopData = $course->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="border-2 border-gray-600"><?php echo e($course_module->name); ?></td>
                <td class="border-2 border-gray-600"><?php echo e($course_module->created_at->diffForHumans()); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="2" class="border-2 border-gray-600">No modules found on this course.</td>
            </tr>
            <?php endif; ?>

        </tbody>
    </table>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\livewire\head-courses-page.blade.php ENDPATH**/ ?>