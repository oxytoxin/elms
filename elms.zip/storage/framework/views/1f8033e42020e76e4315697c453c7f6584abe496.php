<header class="sticky top-0 flex items-center justify-between h-12 p-2 text-gray-300 bg-primary-500">
    <div class="flex items-center left">
        <i class="m-2 icofont-navigation-menu"></i>
        <h1 class="text-sm font-semibold">SULTAN KUDARAT STATE UNIVERSITY</h1>
    </div>
    <div class="flex items-center mr-4 text-2xl right">
        <a href="#"><i class="mx-2 cursor-pointer hover:text-white icofont-wechat"></i></a>
        <a href="#"><i class="mx-2 cursor-pointer hover:text-white icofont-alarm"></i></a>
        <a href="#"><i class="mx-2 cursor-pointer hover:text-white icofont-ui-calendar"></i></a>
        <a href="#"><i class="mx-2 cursor-pointer hover:text-white icofont-question-circle"></i></a>
        <a href="<?php echo e(route('profile.show')); ?>"><i class="mx-2 cursor-pointer hover:text-white icofont-user-alt-4"></i></a>
    </div>
</header><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\includes\student\header.blade.php ENDPATH**/ ?>