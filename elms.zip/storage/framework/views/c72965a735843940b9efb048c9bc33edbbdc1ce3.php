<div class="m-5" x-data="{uiEssay:<?php if ((object) ('uiEssay') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('uiEssay'->value()); ?>')<?php echo e('uiEssay'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('uiEssay'); ?>') <?php endif; ?>}">
    <div x-show.transition="uiEssay" x-cloak class="fixed inset-0 z-50 flex items-center justify-center bg-gray-600 bg-opacity-50">
        <div @click.away="uiEssay=false" id="essay_gradesheet" class="p-4 mx-3 overflow-auto bg-white rounded-lg shadow md:mx-0 md:w-1/2 min-h-halfscreen">
            <h1 class="italic">Question: Lorem ipsum dolor, sit amet consectetur adipisicing elit. Mollitia, dolorum?</h1>
            <hr class="my-1 border border-primary-600">
            <h1 class="text-sm">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Maiores placeat commodi soluta, aperiam, cumque quisquam nulla magni possimus enim voluptate doloribus itaque. Quia minus illum ratione ipsa quis consequuntur doloribus.</h1>
            <div class="w-full overflow-auto">
                <table class="table w-full mt-3 border-2 border-collapse table-auto border-primary-600">
                    <thead>
                        <tr>
                            <th rowspan="2" class="px-3 border-2 border-primary-600">Weight</th>
                            <th rowspan="2" class="px-3 border-2 border-primary-600">Criteria</th>
                            <th colspan="<?php echo e(count($rubric['performance_rating'])); ?>" class="border-2 border-primary-600">Performance Rating</th>
                        </tr>
                        <tr>
                            <?php $__currentLoopData = $rubric['performance_rating']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="px-3 border-2 border-primary-600"><?php echo e($rating); ?></th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rubric['criteria']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-2 py-4 text-center border-2 border-primary-600"><?php echo e($criterion['weight']); ?>%</td>
                            <td class="text-center border-2 border-primary-600"><?php echo e($criterion['name']); ?></td>
                            <?php $__currentLoopData = $rubric['performance_rating']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="text-center border-2 border-primary-600"><input wire:model="weights.<?php echo e($id); ?>" <?php echo e($loop->index == 0 ? 'checked' : ''); ?> type="radio" name="<?php echo e($criterion['name']."-rating"); ?>" value="<?php echo e($this->getRating($key)); ?>" class="mr-1 border border-gray-600 cursor-pointer form-radio" id=""><?php echo e($this->getRating($key)); ?>%</td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="my-2 text-sm">
                <h1>Max score: <span class="font-semibold"><?php echo e($essay_maxscore); ?> pts</span></h1>
                <h1>Student score: <span class="font-semibold"><?php echo e($essay_score); ?> pts</span></h1>
                <div class="my-1">
                    <button @click="uiEssay=false" class="px-2 py-1 mb-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-800">CANCEL</button>
                    <button @click="uiEssay=false" wire:click="gradeEssay" class="px-2 py-1 mb-2 text-xs font-semibold text-white bg-primary-500 hover:bg-primary-600">GRADE</button>
                </div>
            </div>
        </div>
    </div>

    <h1 class="text-2xl font-semibold">Grade Task Submission</h1>
    <h1 class="font-semibold uppercase"><span><?php echo e($task->task_type->name); ?> |</span> <?php echo e($task->name); ?></h1>
    <h1 class="italic font-semibold uppercase">COURSE: <span class="text-orange-500"><?php echo e($task->module->name); ?></span></h1>
    <div class="flex flex-col my-2 text-sm md:flex-row md:justify-between">
        <div>
            <h1>Task max score: <span class="font-bold"><?php echo e($task->max_score); ?> pts</span></h1>
            <h1>Student score: <span class="font-bold"><?php echo e($this->getTotalScore()); ?> pts</span></h1>
        </div>
    </div>
    <div class="flex flex-col items-center justify-center md:flex-row">
        <h1 class="text-sm font-semibold uppercase"><i class="ml-4 mr-2 text-green-400 text-opacity-50 icofont-square"></i>Correct/Partial</h1>
        <h1 class="text-sm font-semibold uppercase"><i class="ml-4 mr-2 text-yellow-300 text-opacity-50 icofont-square"></i>UnGraded</h1>
        <h1 class="text-sm font-semibold uppercase"><i class="ml-4 mr-2 text-red-400 text-opacity-50 icofont-square"></i>Wrong</h1>
    </div>
    <?php $__currentLoopData = $task_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="p-2 mx-5 mt-3 <?php echo e($items[$key] ? ($items[$key]['isCorrect'] ? 'bg-green-400 bg-opacity-50' : 'bg-red-400 bg-opacity-50') : 'bg-yellow-300 bg-opacity-50'); ?> border border-gray-700 rounded-lg shadow-lg">
        <?php if($item['essay']): ?>
        <button wire:click="showEssayGrader(<?php echo e($key); ?>)" class="px-2 py-1 mb-2 text-xs font-semibold text-white bg-primary-500 hover:bg-primary-600">GRADE</button>
        <?php elseif(!$item['options']): ?>
        <div>
            <button wire:click="markAsCorrect(<?php echo e($key); ?>)" class="px-2 py-1 mb-2 text-xs font-semibold text-white bg-primary-500 hover:bg-primary-600">CORRECT</button>
            <button wire:click="markAsWrong(<?php echo e($key); ?>)" class="px-2 py-1 mb-2 text-xs font-semibold text-white bg-red-600 hover:bg-red-800">WRONG</button>
            <?php if($item['attachment']): ?>
            <div>
                <input type="number" placeholder="Partial Score..." wire:model="partial.<?php echo e($key); ?>" class="py-1 text-xs form-input">
                <button wire:click="partialPoints(<?php echo e($key); ?>)" class="px-2 py-1 mt-2 mb-2 text-xs font-semibold text-white md:mt-0 bg-primary-500 hover:bg-primary-600">PARTIAL</button>
            </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>
        <?php if(session()->has("partialError$key")): ?>
        <div class="text-xs italic text-red-600">
            <?php echo e(session("partialError$key")); ?>

        </div>
        <?php endif; ?>
        <h1 class="font-semibold text-orange-500">(<?php echo e($item['points']); ?> pt/s.) Question <?php echo e($item['item_no']); ?>. <?php echo e($item['essay'] ? '(Essay)' : ""); ?></h1>
        <h1><?php echo e($item['question']); ?></h1>
        <?php if($item['files']): ?>
        <div class="flex justify-center my-3">
            <?php $__currentLoopData = $item['files']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex flex-col items-center">
                <a target="blank" href="<?php echo e(asset('storage'.'/'.$file['url'])); ?>" class="text-sm italic underline text-primary-500">View Attachment: <?php echo e($file['name']); ?></a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>

    <?php if(isset($answers[$key]['files'])): ?>
        <div class="p-3 my-2 bg-white border shadow">
            <h1 class="text-sm font-semibold uppercase">Student Attachments:</h1>
            <?php $__currentLoopData = $answers[$key]['files']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a target="blank" href="<?php echo e(asset('storage'.'/'.$file['url'])); ?>" class="text-sm italic underline text-primary-500"><?php echo e(is_array($file) ? $file['name'] : $file->getClientOriginalName()); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <hr class="my-2 border border-primary-600">
    <h1 class="text-sm font-semibold">Student answered: <?php echo e($item['essay'] ? "(Word count: ".str_word_count($answers[$key]['answer']).")" : ''); ?></h1>
    <p><?php echo e($answers[$key]['answer']); ?></p>
    <span class="p-1 text-xs font-bold text-white bg-primary-500">Score: <?php echo e($items[$key]['score'] ?? 0); ?> pts</span>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($this->verifyItems()): ?>
    <button wire:click="finishGrading" class="float-right p-3 mt-5 mr-5 font-semibold text-white bg-primary-500 hover:bg-primary-600">FINISH GRADING</button>
    <?php endif; ?>
</div>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.student.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\livewire\teacher\grade-task.blade.php ENDPATH**/ ?>