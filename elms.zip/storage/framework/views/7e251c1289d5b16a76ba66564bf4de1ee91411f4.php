
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('includes.head.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="md:p-3">
    <div class="flex min-h-screen">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('head-courses-page',['course'=>$course])->html();
} elseif ($_instance->childHasBeenRendered('0L2zLoG')) {
    $componentId = $_instance->getRenderedChildComponentId('0L2zLoG');
    $componentTag = $_instance->getRenderedChildComponentTagName('0L2zLoG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0L2zLoG');
} else {
    $response = \Livewire\Livewire::mount('head-courses-page',['course'=>$course]);
    $html = $response->html();
    $_instance->logRenderedChild('0L2zLoG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
        <?php echo $__env->make('includes.head.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views/pages/head/courses/course.blade.php ENDPATH**/ ?>