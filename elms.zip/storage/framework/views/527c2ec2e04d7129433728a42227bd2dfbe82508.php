
<?php $__env->startSection('content'); ?>
    <div class="w-3/4 p-3 mx-auto my-5 shadow-lg">
        <h1 class="font-semibold">Event Details</h1>
        <hr class="border-2 border-primary-600">
        <br>
        <h1><?php echo e($event->title); ?></h1>
        <h1>Event Description: <?php echo e($event->description); ?></h1>
        <h1>Created by: <?php echo e($event->user->name); ?></h1>
        <h1>Created at: <?php echo e($event->created_at->format('M d, Y')); ?></h1>
        <h1>Event Starts at: <?php echo e($event->start->format('M d, Y - g:i A')); ?></h1>
        <?php if($event->end): ?>
        <h1>Event Ends at: <?php echo e($event->allDay ?  $event->end->format('M d, Y') : $event->end->format('M d, Y - g:i A')); ?></h1>
        <?php endif; ?>
        <br>
        <a href="/" class="p-2 font-semibold text-white bg-primary-500">Back to Home</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\pages\event.blade.php ENDPATH**/ ?>