<div class="px-2 mx-4 md:w-5/6">
    <h1 class="text-xl font-semibold"><?php echo e($course->name); ?> <i class="ml-5 cursor-pointer icofont-edit"
            onclick="document.querySelector('#course_edit').style.display='flex'"></i><i
            onclick="confirm('Confirm delete?') || event.stopImmediatePropagation()" wire:click.prevent="deleteCourse"
            class="ml-5 text-red-600 cursor-pointer icofont-trash"></i><i wire:loading wire:target="enrolFaculty"
            class="fa fa-spinner fa-spin"></i></h1>
    <div class="box-border flex text-lg text-gray-300 border-2 border-black">
        <a href="#" wire:click="$set('tab','faculty')"
            class="flex items-center justify-center w-1/2 <?php echo e($tab == 'faculty' ?  'bg-primary-500 text-gray-700' : ''); ?>">
            <div class="font-bold text-center uppercase hover:text-gray-700">ENROL FACULTY</div>
        </a>
        <a href="#" wire:click="$set('tab','modules')"
            class="flex items-center justify-center w-1/2 <?php echo e($tab == 'modules' ?  'bg-primary-500 text-gray-700' : ''); ?>">
            <div class="font-bold text-center uppercase hover:text-gray-700">UPLOAD MODULE RESOURCES</div>
        </a>
    </div>
    <form id="course_edit" action="#" class="flex-col hidden p-2 my-3 border-2 border-gray-600 rounded-lg">
        <label for="course_name" class="mt-2">Course Name</label>
        <input wire:model.defer="newCourseName" name="course_name" type="text" class="form-input">
        <?php $__errorArgs = ['newCourseName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label for="course_code" class="mt-2">Course Code</label>
        <input wire:model.defer="newCourseCode" name="course_code" placeholder="ABC123" type="text" class="form-input">
        <?php $__errorArgs = ['newCourseCode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <button type="submit" onclick="confirm('Confirm changes?') || event.stopImmediatePropagation()"
            wire:click.prevent="editCourse" class="px-10 py-2 mt-2 rounded-lg bg-primary-500">Save</button>
        <button wire:click.prevent="" onclick="document.querySelector('#course_edit').style.display = 'none'"
            class="px-10 py-2 mt-2 rounded-lg bg-primary-500">Cancel</button>
    </form>
    <div class="italic text-green-400">
        <?php if(session()->has('course_updates')): ?>
        <?php echo e(session('course_updates')); ?>

        <?php endif; ?>
    </div>
    <script>
        window.addEventListener('course-updated', (event) => {
            document.querySelector('#course_edit').style.display = 'none';
        });
    </script>
    <?php if($tab == 'faculty'): ?>
    <div class="mt-2">
        <form wire:submit.prevent="enrolFaculty">
            <?php echo csrf_field(); ?>
            <label for="email">Faculty Email</label>
            <div class="italic text-green-400">
                <?php if(session()->has('message')): ?>
                <?php echo e(session('message')); ?>

                <?php endif; ?>
            </div>
            <div class="flex flex-col items-center mt-2 md:flex-row">
                <input type="email" class="w-full form-input" placeholder="user@email.com" autocomplete="off" autofocus
                    name="email" wire:model.defer="email">
                <button
                    class="p-2 mt-2 ml-2 text-white whitespace-no-wrap rounded-lg md:mt-0 hover:text-black focus:outline-none bg-primary-500">Enroll
                    Faculty</button>
            </div>
        </form>
    </div>
    <h1 class="my-2 font-bold">Course Faculty List</h1>
    <table class="table w-full border-2 border-collapse border-gray-600">
        <thead class="">
            <th class="border-2 border-gray-600">Name</th>
            <th class="border-2 border-gray-600">Email</th>
        </thead>
        <tbody class="text-center">
            <?php $__empty_1 = true; $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="border-2 border-gray-600"><?php echo e($teacher->user->name); ?></td>
                <td class="border-2 border-gray-600"><?php echo e($teacher->user->email); ?><i
                        onclick="confirm('Confirm removal of faculty member?') || event.stopImmediatePropagation()"
                        wire:click.prevent="removeFaculty(<?php echo e($teacher->id); ?>)"
                        class="ml-5 text-red-600 cursor-pointer icofont-trash"></i></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="2" class="border-2 border-gray-600">No faculty member found on this course.</td>
            </tr>
            <?php endif; ?>

        </tbody>
    </table>
    <?php endif; ?>
    <?php if($tab == 'modules'): ?>
    <div class="mt-2">
        <form wire:submit.prevent="addModule" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <label class="font-semibold" for="title">Module Title<i wire:loading wire:target="addModule"
                    class="fa fa-spinner fa-spin"></i></label>
            <input wire:model="moduleName" type="text" class="block w-full form-input" autocomplete="off"
                placeholder="Module Title" autofocus name="moduleName">
            <?php $__errorArgs = ['moduleName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="flex flex-col items-center mt-2 md:flex-row">
                <input type="file" required wire:model="module" class="w-full form-input" autocomplete="off" autofocus
                    id="file<?php echo e($fileId); ?>" name="module">
                <?php $__errorArgs = ['module'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <button wire:target="module" wire:loading.remove
                    class="p-2 mt-2 ml-2 text-white rounded-lg md:mt-0 hover:text-black focus:outline-none bg-primary-500">Upload
                    Module</button>
            </div>
        </form>
    </div>

    <div wire:target="module" wire:loading>
        <h1 class="italic font-semibold text-green-400">Uploading Module. Please
            wait...<i class="fa fa-spinner fa-spin"></i></h1>
    </div>
    <div class="italic text-green-400">
        <?php if(session()->has('message')): ?>
        <?php echo e(session('message')); ?>

        <?php endif; ?>
    </div>
    <h1 class="mt-2 font-bold">Course Module List</h1>
    <div class="italic text-green-400">
        <?php if(session()->has('module_deleted')): ?>
        <?php echo e(session('module_deleted')); ?>

        <?php endif; ?>
    </div>
    <table class="table w-full border-2 border-collapse border-gray-600 table-fixed">
        <thead class="">
            <th class="border-2 border-gray-600">Title</th>
            <th class="border-2 border-gray-600">Date Added</th>
        </thead>
        <tbody class="text-center">
            <?php $__empty_1 = true; $__currentLoopData = $course->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course_module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="border-2 border-gray-600"><?php echo e($course_module->name); ?></td>

                <td class="border-2 border-gray-600"><?php echo e($course_module->created_at->diffForHumans()); ?><i
                        onclick="confirm('Are you sure you want to delete this module?')|| event.stopImmediatePropagation()"
                        wire:click.prevent="deleteModule(<?php echo e($course_module->id); ?>)"
                        class="ml-4 text-red-600 cursor-pointer icofont-trash"></i>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="2" class="border-2 border-gray-600">No modules found on this course.</td>
            </tr>
            <?php endif; ?>

        </tbody>
    </table>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views/livewire/head-courses-page.blade.php ENDPATH**/ ?>