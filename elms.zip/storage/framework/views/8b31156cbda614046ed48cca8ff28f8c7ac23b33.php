<div class="w-full p-3 shadow-lg">
    <h1 class="mt-3 text-lg font-semibold">CREATE COURSE <i wire:loading class="fa fa-spin fa-spinner"></i></h1>
    <div class="italic text-green-400">
        <?php if(session('message')): ?>
        <?php echo e(session('message')); ?>

        <?php endif; ?>
    </div>
    <div class="mt-3">
        <form wire:submit.prevent="addCourse" class="px-2">
            <div class="flex w-full">
                <div class="flex-1 px-2">
                    <label for="course_title">Course Title</label>
                    <input wire:model.defer="course_title" name="course_title" type="text" placeholder="Enter Course Title"
                        autocomplete="off" class="w-full form-input">
                    <?php $__errorArgs = ['course_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="flex-1 px-2">
                    <label for="course_code">Course code</label>
                    <input wire:model.defer="course_code" name="course_code" type="text" placeholder="ABC123"
                        autocomplete="off" class="w-full form-input">
                    <?php $__errorArgs = ['course_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="px-2">
                <button type="submit"
                    class="p-3 mt-2 font-semibold text-white rounded-lg hover:text-primary-600 focus:outline-none bg-primary-500">ADD
                    COURSE</button>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\livewire\create-course.blade.php ENDPATH**/ ?>