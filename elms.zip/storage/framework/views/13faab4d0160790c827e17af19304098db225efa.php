
<?php $__env->startSection('content'); ?>
<div class="px-5">
    <div class="flex">
        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('teacher-courses-page',['course'=>$course])->html();
} elseif ($_instance->childHasBeenRendered('ETVk7yZ')) {
    $componentId = $_instance->getRenderedChildComponentId('ETVk7yZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('ETVk7yZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ETVk7yZ');
} else {
    $response = \Livewire\Livewire::mount('teacher-courses-page',['course'=>$course]);
    $html = $response->html();
    $_instance->logRenderedChild('ETVk7yZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.teacher.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\pages\teacher\courses\course.blade.php ENDPATH**/ ?>