<a href="/">
    <div class="w-16 h-16">
        <img src="<?php echo e(asset('img/sksulogo.png')); ?>" alt="logo">
    </div>
</a>
<?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\vendor\jetstream\components\authentication-card-logo.blade.php ENDPATH**/ ?>