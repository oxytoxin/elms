<div x-data="{showrubric: <?php if ((object) ('showrubric') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showrubric'->value()); ?>')<?php echo e('showrubric'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showrubric'); ?>') <?php endif; ?>}" class="p-2 m-4 shadow">
    <h1 class="text-xl font-semibold">TASK CREATOR</h1>
    <br>
    <h1>For Course: <span class="italic"><?php echo e($module->course->name); ?></span></h1>
    <h1>For Module: <span class="italic"><?php echo e($module->name); ?></span></h1>
    <h1>Task Type: <?php echo e(strtoupper($type)); ?></h1>
    <br>
    <label for="task_name">Task Name:</label>
    <input type="text" wire:model.defer="task_name" placeholder="Enter task name..." class="w-full form-input">
    <?php $__errorArgs = ["task_name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <h1 class="text-xs italic text-red-600"><?php echo e($message); ?></h1>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <h1>Date Due:</h1>
    <i class="fas fa-spin fa-spinner" wire:loading></i>
    <input type="date" wire:model.defer="date_due" class="m-2 form-input" name="date_due" id="date_due">
    <input type="time" wire:model.defer="time_due" class="m-2 form-input" name="time_due" id="time_due">
    <hr class="border border-primary-600">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="p-2 m-2 <?php echo e($key%2 ? 'bg-primary-500 text-white' : ''); ?> relative shadow-lg">
                <?php if($key != 0): ?>
                    <div class="absolute right-0 pr-2"><i wire:click.prevent="removeItem(<?php echo e($key); ?>)" class="text-red-600 cursor-pointer icofont-close"></i></div>
                <?php endif; ?>
                <input type="number" wire:model="items.<?php echo e($key); ?>.points" class="w-28 mr-2 <?php echo e($key%2 ? 'text-black' : ''); ?> form-input">
                <span class="mr-2">(points)</span>
                <label for="question_<?php echo e($key+1); ?>"><i class="mr-2 icofont-question-circle"></i>Question <?php echo e($key + 1); ?></label>
                <div class="flex items-center my-2">
                    <input type="text" placeholder="Enter your question or instruction..." wire:model.defer="items.<?php echo e($key); ?>.question" class="w-full <?php echo e($key%2 ? 'text-black' : ''); ?> form-input">
                </div>
                <?php $__errorArgs = ["items.$key.question"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <h1 class="text-xs italic text-red-600"><?php echo e($message); ?></h1>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ["items.$key.points"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <h1 class="text-xs italic text-red-600"><?php echo e($message); ?></h1>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <div>
                    <input type="file" id="item_<?php echo e($key); ?>_files" class="w-full form-input <?php echo e($key%2 ? 'text-black' : ''); ?>" wire:model="items.<?php echo e($key); ?>.files" multiple>
                        <div class="flex flex-col items-center mt-2 text-white md:flex-row">
                            <button class="w-full p-2 my-1 whitespace-no-wrap bg-gray-500 rounded-lg md:w-auto hover:bg-green-300 focus:outline-none hover:text-primary-600" wire:click.prevent="addOption(<?php echo e($key); ?>)"><i class="mr-1 icofont-plus-circle"></i>Add Option</button>
                            <button wire:click="TorFtrigger(<?php echo e($key); ?>)" class="p-2 w-full md:w-auto my-1 md:ml-3 hover:text-primary-600 bg-gray-500 <?php echo e($item['torf'] ? 'bg-primary-600' : 'bg-gray-500'); ?> rounded-lg hover:bg-green-300"><i class="icofont-check"></i>True or False?</button>
                            <button wire:click="Essaytrigger(<?php echo e($key); ?>)" class="p-2 w-full md:w-auto my-1 md:ml-3 hover:text-primary-600 bg-gray-500 <?php echo e($item['essay'] ? 'bg-primary-600' : 'bg-gray-500'); ?> rounded-lg hover:bg-green-300"><i class="icofont-file-document"></i>Essay</button>
                            <button wire:click="ExpectAttachment(<?php echo e($key); ?>)" class="p-2 w-full md:w-auto my-1 md:ml-3 hover:text-primary-600 bg-gray-500 <?php echo e($item['attachment'] ? 'bg-primary-600' : 'bg-gray-500'); ?> rounded-lg hover:bg-green-300"><i class="icofont-attachment"></i>Require File Attachment?</button>
                        </div>
                   <div class="flex flex-col">
                    <?php if(count($item['options'])): ?>
                        <h1 class="text-sm italic">Double check that the correct option is selected.</h1>
                        <?php $__errorArgs = ["items.$key.answer"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <h1 class="text-xs italic text-red-600"><?php echo e($message); ?></h1>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php endif; ?>
                    <?php $__currentLoopData = $item['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="relative flex items-center w-full mt-2">
                        <input type="radio" wire:model="items.<?php echo e($key); ?>.answer" name="item_<?php echo e($key); ?>_answer" class="mr-2 form-radio" value="<?php echo e($option); ?>">
                        <input placeholder="Enter an option..." wire:model.defer="items.<?php echo e($key); ?>.options.<?php echo e($id); ?>" type="text" class="form-input flex-1 <?php echo e($key%2 ? 'text-black' : ''); ?>" name="option">
                        <i class="absolute ml-2 text-2xl text-red-600 cursor-pointer inset-y-2 right-1 icofont-trash" wire:click.prevent="removeOption(<?php echo e($key); ?>,<?php echo e($id); ?>)"></i>
                    </div>
                    <?php $__errorArgs = ["items.$key.options.$id"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <h1 class="text-xs italic text-red-600"><?php echo e($message); ?></h1>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="flex flex-col items-center p-4 md:flex-row">
            <button class="w-full p-2 my-1 text-white whitespace-no-wrap bg-gray-500 rounded-lg md:w-auto focus:outline-none hover:bg-green-300 hover:text-primary-600" wire:click.prevent="addItem(<?php echo e(count($items)); ?>)"><i class="mr-2 icofont-plus-circle"></i>Add Item</button>
            <span class="w-full p-2 my-1 font-semibold text-center text-white bg-orange-500 rounded-lg md:ml-3 md:w-auto">Total points: <?php echo e($total_points); ?></span>
            <button wire:click.prevent="saveTask" class="w-full p-2 px-5 my-1 text-white rounded-lg md:ml-3 md:w-auto hover:text-primary-600 bg-primary-500 focus:outline-none">Submit Task</button>
        </div>
        <div x-cloak x-show.transition="showrubric" class="fixed inset-0 z-50 flex items-center justify-center bg-gray-500 bg-opacity-50">
            <div class="relative mx-5 overflow-hidden bg-white rounded-lg shadow-lg md:w-1/2 min-h-halfscreen">
                <div class="p-3">
                    <h1>This task contains an essay item and requires you to set a rubric for grading.</h1>
                    <hr class="border border-primary-600">
                    <div class="w-full overflow-auto">
                        <table class="table w-full mt-3 border-2 border-collapse table-auto border-primary-600">
                            <thead>
                                <tr>
                                    <th rowspan="2" class="px-3 border-2 border-primary-600">Weight</th>
                                    <th rowspan="2" class="px-3 border-2 border-primary-600">Criteria</th>
                                    <th colspan="<?php echo e(count($rubric['performance_rating'])); ?>" class="border-2 border-primary-600">Performance Rating</th>
                                </tr>
                                <tr>
                                    <?php $__currentLoopData = $rubric['performance_rating']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th class="px-3 border-2 border-primary-600"><?php echo e($rating); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $rubric['criteria']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-2 py-4 text-center border-2 border-primary-600"><i wire:click="editCriterionWeight(<?php echo e($id); ?>)" class="mx-2 cursor-pointer hover:text-primary-600 icofont-ui-edit text-primary-500"></i><?php echo e($criterion['weight']); ?>%</td>
                                    <td class="text-center border-2 border-primary-600"><i wire:click="editCriterionName(<?php echo e($id); ?>)" class="mx-2 cursor-pointer hover:text-primary-600 icofont-ui-edit text-primary-500"></i><?php echo e($criterion['name']); ?></td>
                                    <?php $__currentLoopData = $rubric['performance_rating']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td class="text-center border-2 border-primary-600"><?php echo e($this->getRating($key)); ?>%</td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <button wire:click.prevent="equalWeights" class="p-2 my-1 text-orange-600 bg-yellow-300 hover:bg-yellow-400">Set Equal Weights</button>
                    <button wire:click.prevent="resetRubric" class="p-2 my-1 text-white bg-red-600 hover:bg-red-700">Reset to default</button>
                    <div class="mt-3 control-panel">
                        <div class="py-3 border-b-2 border-primary-600">
                            <h1 class="text-xs font-semibold"><i class="mr-1 icofont-info-circle text-yellow"></i>Note: Adding items resets their weights to equal percentages.</h1>
                            <?php if(session()->has('max_criteria')): ?>
                            <div class="text-xs italic text-red-600">
                                <?php echo e(session('max_elements')); ?>

                            </div>
                            <?php endif; ?>
                            <?php $__errorArgs = ['new_criterion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <h1 class="text-sm italic text-red-600"><?php echo e($message); ?></h1>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__errorArgs = ['new_performance_rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <h1 class="text-sm italic text-red-600"><?php echo e($message); ?></h1>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="flex flex-col mt-2 md:flex-row">
                                <input wire:model.lazy="new_criterion" type="text" class="flex-1 mr-2 form-input" placeholder="Your new criterion...">
                                <button wire:click.prevent="addCriterion" class="self-end w-full p-2 px-10 mt-2 font-semibold text-white md:mt-0 md:w-auto bg-primary-500 hover:bg-primary-600">ADD CRITERION</button>
                            </div>
                            <div class="flex flex-col mt-2 md:flex-row">
                                <input wire:model.lazy="new_performance_rating" type="text" class="flex-1 mr-2 form-input" placeholder="Your new performance rating...">
                                <button wire:click.prevent="addPerformanceRating" class="self-end w-full p-2 px-10 mt-2 font-semibold text-white md:mt-0 md:w-auto bg-primary-500 hover:bg-primary-600">ADD PERFORMANCE RATING</button>
                            </div>
                        </div>
                        <div>
                            <?php if(session()->has('weights_error')): ?>
                            <div class="mt-2 text-xs italic font-semibold text-red-600">
                                <?php echo e(session('weights_error')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <button wire:click.prevent="saveRubric" class="p-3 px-10 mt-2 font-semibold text-white bg-primary-500 hover:bg-primary-600">SAVE RUBRIC</button>
                        <button wire:click="hideRubricEdit" class="p-3 px-10 mt-2 font-semibold text-white bg-primary-500 hover:bg-primary-600">CANCEL</button>
                    </div>
                </div>
                <div x-data="{showEdit: <?php if ((object) ('showEdit') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showEdit'->value()); ?>')<?php echo e('showEdit'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('showEdit'); ?>') <?php endif; ?>}" x-cloak x-show.transition="showEdit" class="absolute inset-0 flex flex-col items-center justify-center px-3 bg-blue-400 bg-opacity-50">
                    <h1 class="p-3 my-4 bg-white rounded-lg"><?php echo e($this->editDialogTitle); ?></h1>
                    <input wire:model.lazy="editDialogInputValue" type="text" class="w-full p-2 form-input" value="<?php echo e($editDialogInputValue); ?>">
                    <?php $__errorArgs = ['editDialogInputValue'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <h1 class="text-sm italic text-red-600"><?php echo e($message); ?></h1>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <div>
                        <button wire:click.prevent="updateValues" class="p-3 px-10 mt-3 font-semibold text-white bg-primary-500 hover:bg-primary-600">SAVE</button>
                        <button @click="showEdit = false" class="p-3 px-10 mt-3 font-semibold text-white bg-primary-500 hover:bg-primary-600">CANCEL</button>
                    </div>
                </div>
            </div>
        </div>
</div>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.teacher.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    <script>
        window.addEventListener('DOMContentLoaded',function(){
            Livewire.on('item-added', () => {
                window.scrollTo(0,document.body.scrollHeight);
        })
        })
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\livewire\task-maker.blade.php ENDPATH**/ ?>