
<?php $__env->startSection('content'); ?>
<div class="px-5">
    <div class="flex">
        <div class="w-full px-2 m-4">
            <h1 class="my-2 text-2xl"><i class="mr-2 icofont-star"></i><?php echo e($module->name); ?></h1>
            <h1 class="font-semibold">Module Resources</h1>
            <?php $__empty_1 = true; $__currentLoopData = $module->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="flex items-center my-2">
                <a href="<?php echo e(route('file.download',['file'=> $file->id])); ?>" target="_blank">
                    <h1 class="italic underline text-primary-600"><i
                            class="mr-2 icofont-download-alt"></i><?php echo e($file->name); ?>

                    </h1>
                </a>
                <a href="<?php echo e(route('head.preview',['file'=> $file->id])); ?>" target="_blank" rel="noopener noreferrer"
                    class="px-2 ml-3 text-white border hover:text-black border-primary-600 bg-primary-500">Preview</a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h1>No modules found.</h1>
            <?php endif; ?>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.head.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\pages\head\modules\module.blade.php ENDPATH**/ ?>