<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($name, $params)->html();
} elseif ($_instance->childHasBeenRendered('eOoKwhX')) {
    $componentId = $_instance->getRenderedChildComponentId('eOoKwhX');
    $componentTag = $_instance->getRenderedChildComponentTagName('eOoKwhX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('eOoKwhX');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $html = $response->html();
    $_instance->logRenderedChild('eOoKwhX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\vendor\livewire\livewire\src\views\mount-component.blade.php ENDPATH**/ ?>