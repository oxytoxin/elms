<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount($name, $params)->html();
} elseif ($_instance->childHasBeenRendered('JmEoXs0')) {
    $componentId = $_instance->getRenderedChildComponentId('JmEoXs0');
    $componentTag = $_instance->getRenderedChildComponentTagName('JmEoXs0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('JmEoXs0');
} else {
    $response = \Livewire\Livewire::mount($name, $params);
    $html = $response->html();
    $_instance->logRenderedChild('JmEoXs0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\vendor\livewire\livewire\src\views\mount-component.blade.php ENDPATH**/ ?>