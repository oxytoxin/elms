
<?php $__env->startSection('content'); ?>
<div class="px-5">
    <div class="flex">
        <div>
            <h1 class="text-2xl font-semibold">COURSE MANAGER</h1>
            <div class="py-2">
                <a href="<?php echo e(route('head.create_course')); ?>"
                    class="p-2 font-semibold text-white rounded-lg hover:text-primary-600 bg-primary-500"><i class="mr-2 icofont-plus"></i>ADD
                    COURSE</a>
            </div>
            <div class="grid gap-2 mt-2 xxl:grid-cols-5 md:grid-cols-4">
                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="w-full overflow-hidden h-80">
                    <div class="h-1/2"><img src="<?php echo e($course->image->url); ?>" class="object-cover w-full h-full"
                            alt="course"></div>
                    <div class="p-2 text-white h-4/12 bg-secondary-500">
                        <h1 class="text-sm text-center"><?php echo e($course->name); ?></h1>
                        <h1 class="font-semibold text-center text-orange-500"><?php echo e($course->code); ?></h1>
                    </div>
                    <div class="h-2/12">
                        <a href="<?php echo e(route('head.course',['course'=>$course->id])); ?>"
                            class="flex items-center justify-center w-full h-full p-1 text-white hover:text-black bg-primary-600">
                            View Course
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h1>No Course Found</h1>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.head.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\pages\head\courses\index.blade.php ENDPATH**/ ?>