
<?php $__env->startSection('content'); ?>
<div class="m-4 px-7">
    <h1 class="text-2xl font-semibold uppercase">TASKS - <?php echo e($task_type->name); ?></h1>
    <div class="grid gap-3 mt-4 md:grid-cols-3">
    <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <a href="<?php echo e(route('teacher.task',['task'=> $task->id])); ?>">
                <div class="p-3 rounded-lg shadow-lg hover:bg-green-300 focus:outline-none bg-primary-500 min-h-24">
                    <h1><?php echo e($task->name); ?></h1>
                    <h1 class="text-sm font-semibold text-white"><?php echo e($task->module->course->name); ?> <span class="text-black">[<?php echo e($task->module->course->code); ?>]</span></h1>
                    <h1 class="text-sm italic font-semibold">~<?php echo e($task->module->name); ?></h1>
                    <h1 class="text-sm font-semibold">Submissions: <?php echo e($task->submissions); ?></h1>
                    <h1 class="text-sm font-semibold">Graded: <?php echo e($task->graded); ?></h1>
                    <h1 class="text-sm font-semibold">Ungraded: <?php echo e($task->ungraded); ?></h1>
                    <h1 class="text-sm font-semibold text-red-600">Date due: <?php echo e($task->deadline->format('h:i a, m/d/Y')); ?></h1>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h1>Hooray! Nothing to do here yet.</h1>
            <?php endif; ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.teacher.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\pages\teacher\tasks.blade.php ENDPATH**/ ?>