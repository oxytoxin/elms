

<?php $__env->startSection('content'); ?>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('task-maker', ['user' => $user])->html();
} elseif ($_instance->childHasBeenRendered('RRvD3mG')) {
    $componentId = $_instance->getRenderedChildComponentId('RRvD3mG');
    $componentTag = $_instance->getRenderedChildComponentTagName('RRvD3mG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RRvD3mG');
} else {
    $response = \Livewire\Livewire::mount('task-maker', ['user' => $user]);
    $html = $response->html();
    $_instance->logRenderedChild('RRvD3mG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\pages\taskmaker.blade.php ENDPATH**/ ?>