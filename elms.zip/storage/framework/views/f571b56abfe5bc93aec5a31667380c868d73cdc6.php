<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo e(csrf_field()); ?>

    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="/test" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <label for="file">File</label>
        <input type="file" name="file" id="file">
        <input type="submit" value="Submit">
    </form>
    <?php if(isset($match)): ?>
        <iframe src="https://docs.google.com/presentation/d/<?php echo e($match['id']); ?>/preview" frameborder="0" style="width: 100vw; height: 100vh;"></iframe>
    <?php endif; ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\test.blade.php ENDPATH**/ ?>