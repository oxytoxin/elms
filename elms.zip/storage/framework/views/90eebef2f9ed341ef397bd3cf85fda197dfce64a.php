<!DOCTYPE html>
<html oncontextmenu="return false" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'ELMS')); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,400;0,500;0,600;0,700;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fa-min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('icofont/icofont.min.css')); ?>">
    <?php echo \Livewire\Livewire::styles(); ?>

    <script src="https://cdn.jsdelivr.net/gh/alpinejs/alpine@v2.6.0/dist/alpine.js" defer></script>
    <style>
        [x-cloak] { display: none; }
    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="font-sans antialiased bg-gray-200">
    <div class="flex w-full" x-data="{showSidebar:true, mobile: false}" x-init="()=>{
        if(window.matchMedia('(max-width: 480px)').matches){mobile=true; showSidebar=false;}
    }">
        <aside @click.away="if(mobile)showSidebar = false" x-show="showSidebar"
        x-transition:enter="transition ease-out du ration-200"
        x-transition:enter-start="opacity-0 transform -translate-x-40"
        x-transition:enter-end="opacity-100 transform"
        x-transition:leave="transition ease-in duration-200"
        x-transition:leave-start="opacity-100 transform"
        x-transition:leave-end="opacity-0 transform -translate-x-40"
        class="fixed top-0 z-50 flex-shrink-0 h-screen text-white md:sticky max-w-72 bg-primary-600">
                <?php echo $__env->yieldContent('sidebar'); ?>
        </aside>
        <main class="w-full">
            <header class="sticky top-0 z-40 flex flex-col items-center justify-between px-3 font-semibold text-white min-h-16 md:flex-row bg-primary-500">
                <h1 class="flex items-center text-center"><div x-show="!showSidebar" class="w-12 mx-3 logo">
                    <img src="<?php echo e(asset('img/sksulogo.png')); ?>" alt="logo">
                </div>SULTAN KUDARAT STATE UNIVERSITY - ISULAN CAMPUS</h1>
                <nav class="text-2xl">
                    <a @click="showSidebar = !showSidebar"><i class="mx-2 cursor-pointer hover:text-primary-600 icofont-navigation-menu"></i></a>
                    <a><i class="mx-2 cursor-pointer hover:text-primary-600 icofont-wechat"></i></a>
                    <a href="#"><i class="mx-2 cursor-pointer hover:text-primary-600 icofont-alarm"></i></a>
                    <a href="<?php echo e(\Request()->route()->getPrefix().'/calendar'); ?>"><i class="mx-2 cursor-pointer hover:text-primary-600 icofont-ui-calendar"></i></a>
                    <a href="#"><i class="mx-2 cursor-pointer hover:text-primary-600 icofont-question-circle"></i></a>
                    <a href="<?php echo e(route('profile.show')); ?>"><i
                            class="mx-2 cursor-pointer hover:text-primary-600 icofont-user-alt-4"></i></a>
                    <form class="inline-block" method="POST" action="<?php echo e(route('logout')); ?>">
                        <button type="submit"><i class="mx-2 cursor-pointer hover:text-primary-600 icofont-logout"></i></button>
                    </form>
                </nav>
            </header>
            <article class="flex w-full">
                <section class="w-full pb-5">
                    <?php echo $__env->yieldContent('content'); ?>
                </section>
                <section x-show.transition.duration.750ms.origin.center.right="showSidebar" class="relative flex-col flex-shrink-0 hidden w-64 p-3 lg:flex pinned-items">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('layouts.sidelist')->html();
} elseif ($_instance->childHasBeenRendered('pn1RBGu')) {
    $componentId = $_instance->getRenderedChildComponentId('pn1RBGu');
    $componentTag = $_instance->getRenderedChildComponentTagName('pn1RBGu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('pn1RBGu');
} else {
    $response = \Livewire\Livewire::mount('layouts.sidelist');
    $html = $response->html();
    $_instance->logRenderedChild('pn1RBGu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </section>
            </article>
        </main>
    </div>

    <?php echo $__env->yieldPushContent('modals'); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views/layouts/master.blade.php ENDPATH**/ ?>