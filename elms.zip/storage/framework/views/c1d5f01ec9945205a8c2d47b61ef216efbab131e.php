<div class="p-2 m-4 shadow">
    <h1 class="text-xl font-semibold">TASK PREVIEW</h1>
    <br>
    <h1>For Course: <span class="italic"><?php echo e($task->course->name); ?></span></h1>
    <h1>For Module: <span class="italic"><?php echo e($task->module->name); ?></span></h1>
    <h1>Task Type: <?php echo e(strtoupper($task->task_type->name)); ?></h1>
    <br>
    <label for="task_name">Task Name:</label>
    <span><?php echo e($task->name); ?></span>
    <h1>Date Due: <?php echo e($task->deadline->format('M d, Y')); ?></h1>
        <?php if($task->essay_rubric): ?>
        <hr class="border border-primary-600">
        <div class="w-full my-2 overflow-auto">
            <h1 class="font-semibold text-center">Rubrics for Grading Essay</h1>
            <table class="table w-full mt-3 border-2 border-collapse table-auto border-primary-600">
                <thead>
                    <tr>
                        <th rowspan="2" class="px-3 border-2 border-primary-600">Weight</th>
                        <th rowspan="2" class="px-3 border-2 border-primary-600">Criteria</th>
                        <th colspan="<?php echo e(count($rubric['performance_rating'])); ?>" class="border-2 border-primary-600">Performance Rating</th>
                    </tr>
                    <tr>
                        <?php $__currentLoopData = $rubric['performance_rating']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="px-3 border-2 border-primary-600"><?php echo e($rating); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $rubric['criteria']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $criterion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-2 py-4 text-center border-2 border-primary-600"><?php echo e($criterion['weight']); ?>%</td>
                        <td class="text-center border-2 border-primary-600"><?php echo e($criterion['name']); ?></td>
                        <?php $__currentLoopData = $rubric['performance_rating']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="text-center border-2 border-primary-600"><?php echo e($this->getRating($key)); ?>%</td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    <hr class="border border-primary-600">
    <?php $__currentLoopData = $task_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="p-2 mx-5 <?php $__errorArgs = ['answers'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php if(!isset($answers[$key]['answer']) && !isset($answers[$key]['files'])): ?> <?php echo e('bg-red-300'); ?> <?php endif; ?> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> mt-3 border border-gray-700 rounded-lg shadow-lg">
        <h1 class="font-semibold text-orange-500">(<?php echo e($item['points']); ?> pt/s.) Question <?php echo e($item['item_no']); ?>. (<?php echo e($item['essay'] ? 'Essay' : ''); ?>)</h1>
        <h1><?php echo e($item['question']); ?></h1>
        <?php if($item['files']): ?>
        <div class="flex justify-center my-3">
            <?php $__currentLoopData = $item['files']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex flex-col items-center">
            <a target="blank" href="<?php echo e(asset('storage'.'/'.$file['url'])); ?>" class="text-sm italic underline text-primary-500">View Attachment: <?php echo e($file['name']); ?></a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <?php $__empty_1 = true; $__currentLoopData = $item['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id=>$option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div>
            <input type="radio" readonly id="answer_<?php echo e($item['item_no']); ?>_<?php echo e($option); ?>" name="answer_<?php echo e($item['item_no']); ?>" value="<?php echo e($option); ?>" class="form-radio">
            <label for="answer_<?php echo e($item['item_no']); ?>_<?php echo e($option); ?>"><?php echo e($option); ?></label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

    <?php endif; ?>

    <?php if($item['options']): ?>
    <br>
    <h1>Correct Answer: <span class="font-semibold"><?php echo e($item['options'][$item['answer']]); ?></span></h1>
    <?php endif; ?>
    <br>
    <?php if(isset($answers[$key]['files'])): ?>
        <div class="p-3 mb-1 bg-white border shadow">
            <h1 class="text-sm font-semibold uppercase">Your Attachments:</h1>
            <?php $__currentLoopData = $answers[$key]['files']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h1 class="text-sm italic"><?php echo e(is_array($file) ? $file['name'] : $file->getClientOriginalName()); ?></h1>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
    <?php if($item['attachment']): ?>
    <label class="text-xs font-semibold uppercase" for="answer_<?php echo e($key); ?>_files">Add Attachment</label>
    <input type="file" readonly name="answer_<?php echo e($key); ?>_files" id="answer_<?php echo e($key); ?>_files" multiple class="w-full my-2 form-input">
    <?php endif; ?>
    <?php if($item['essay']): ?>
    <textarea wire:key="item_<?php echo e($key); ?>_textarea" placeholder="Your answer..." readonly cols="30" rows="5" class="w-full border-2 border-gray-700 form-textarea"></textarea>
    <?php else: ?>
    <?php if(!$item['options']): ?>
    <input type="text" class="w-full border-2 border-gray-700 form-input" placeholder="Your answer..." wire:model="answers.<?php echo e($key); ?>.answer" >
    <?php endif; ?>
    <?php endif; ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="flex flex-col items-center p-4 md:flex-row">
        <span class="w-full p-2 my-1 font-semibold text-center text-white bg-orange-500 rounded-lg md:w-auto">Total points: <?php echo e($task->max_score); ?></span>
    </div>
</div>

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.teacher.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\livewire\teacher\task-preview.blade.php ENDPATH**/ ?>