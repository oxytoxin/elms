
<?php $__env->startSection('content'); ?>
<div class="px-5">
    <div class="flex">
        <div class="mx-4">
            <h1 class="p-2 font-semibold">COURSE MANAGER</h1>
            <div class="grid gap-2 p-2 md:grid-cols-4 xxl:grid-cols-5">
                <?php $__empty_1 = true; $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="w-full overflow-hidden h-80">
                    <div class="h-1/2"><img src=<?php echo e($course->image->url); ?>" class="object-cover w-full h-full"
                            alt="course"></div>
                    <div class="p-2 text-white h-4/12 bg-secondary-500">
                        <h1 class="font-semibold text-center">Course Title</h1>
                    </div>
                    <div class="h-2/12"><a href="#"
                            class="flex items-center justify-center w-full h-full p-1 text-white hover:text-black bg-primary-600">View
                            Course</a></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h1>No Assigned Courses Yet.</h1>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('includes.teacher.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.teacher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\pages\teacher\courses\index.blade.php ENDPATH**/ ?>