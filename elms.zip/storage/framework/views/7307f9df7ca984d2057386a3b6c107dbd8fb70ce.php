<div class="w-full">
    <h1 class="my-5 text-xl font-semibold"><?php echo e($course->name); ?><i wire:loading class="fa fa-spinner fa-spin"></i></h1>
    <div class="box-border flex text-lg text-gray-300 border-2 border-black">
        <a href="#" wire:click="$set('tab','student')"
            class="flex items-center justify-center w-1/2 <?php echo e($tab == 'student' ?  'bg-primary-500 text-gray-700' : ''); ?>">
            <div class="font-bold text-center uppercase hover:text-gray-700">ENROL STUDENT</div>
        </a>
        <a href="#" wire:click="$set('tab','resources')"
            class="flex items-center justify-center w-1/2 <?php echo e($tab == 'resources' ?  'bg-primary-500 text-gray-700' : ''); ?>">
            <div class="font-bold text-center uppercase hover:text-gray-700">UPLOAD MODULE RESOURCES</div>
        </a>
    </div>
    <?php if($tab == 'student'): ?>
    <div class="mt-2">
        <form action="#" wire:submit.prevent="enrolStudent">
            <label for="email">Student Email</label>
            <div class="italic text-green-400">
                <?php if(session()->has('message')): ?>
                <?php echo e(session('message')); ?>

                <?php endif; ?>
            </div>
            <div class="flex flex-col items-center mt-2 md:flex-row">
                <input wire:model="email" type="email" class="w-full form-input" placeholder="student@email.com"
                    autocomplete="off" autofocus name="email">
                <button
                    class="w-full p-2 mt-2 text-white whitespace-no-wrap rounded-lg md:ml-3 md:w-auto md:mt-0 hover:text-black focus:outline-none bg-primary-500">Enrol
                    Student</button>
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <h1 class="text-xs italic text-red-600"><?php echo e($message); ?></h1>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </form>
    </div>
    <h1 class="my-2 font-bold">Course Student List</h1>
    <table class="table min-w-full border-2 border-collapse border-gray-200 divide-y shadow">
        <thead>
            <th>Name</th>
            <th>Email</th>
        </thead>
        <tbody class="text-center">
            <?php $__empty_1 = true; $__currentLoopData = $course->students()->wherePivot('teacher_id',auth()->user()->teacher->id)->get()->reverse(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="divide-x">
                <td><?php echo e($student->user->name); ?></td>
                <td><?php echo e($student->user->email); ?><i
                        onclick="confirm('Confirm removal of student member?') || event.stopImmediatePropagation()"
                        wire:click.prevent="removeStudent(<?php echo e($student->id); ?>)"
                        class="ml-5 text-red-600 cursor-pointer icofont-trash"></i></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="2">No students enrolled.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <?php endif; ?>
    <?php if($tab == 'resources'): ?>
    <div class="mt-2">
        <form action="#">
            <label class="font-semibold" for="module">Select Module</label>
            <select wire:change="updateModule" wire:model="module_id" required class="flex-1 block w-full form-select">
                <option value="0">Select Module</option>
                <?php $__empty_1 = true; $__currentLoopData = $course->modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i=>$module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option wire:key="moduleOption_<?php echo e($i); ?>" value="<?php echo e($module->id); ?>"><?php echo e($module->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
            </select>
            <?php $__errorArgs = ['module_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label class="font-semibold" for="title">Resource Title</label>
            <input wire:model.lazy="title" type="text" class="flex-1 block w-full form-input" autocomplete="off"
                placeholder="Resource Title" autofocus name="title">
            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <label class="font-semibold" for="description">Resource Description</label>
            <textarea wire:model.lazy="description" class="flex-1 w-full resize form-textarea" rows="4" autocomplete="off"
                placeholder="Resource Description" autofocus name="description"></textarea>
            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="flex flex-col items-center mt-2 md:flex-row">
                <input type="file" wire:model="resources" id="file<?php echo e($fileId); ?>" class="w-full form-input"
                    autocomplete="off" required multiple name="resources">
                <button wire:click="addResources" wire:loading.remove wire:target="resources"
                    class="w-full p-2 mt-2 text-white whitespace-no-wrap rounded-lg md:w-auto md:ml-2 md:mt-0 hover:text-black focus:outline-none bg-primary-500">Upload
                    Resource</button>
            </div>
            <?php $__errorArgs = ['resources.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <h1 class="text-xs italic font-semibold text-red-600"><?php echo e($message); ?></h1>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div wire:loading wire:target="addResources,resources">
                <h1 class="italic text-green-400">Uploading resources. Please wait...<i
                        class="fa fa-spinner fa-spin"></i></h1>
            </div>
        </form>
    </div>
    <div class="italic text-green-400">
        <?php if(session()->has('message')): ?>
        <?php echo e(session('message')); ?>

        <?php endif; ?>
    </div>
    <h1 class="my-2 font-bold">Module Resources List</h1>
    <table class="table min-w-full border-2 border-collapse border-gray-200 divide-y shadow">
        <thead>
            <th>Title</th>
            <th># of Files</th>
            <th>Date Added</th>
        </thead>
        <tbody class="text-center">
            <?php if($moduleSelected): ?>
            <?php $__empty_1 = true; $__currentLoopData = $moduleSelected->resources()->where('teacher_id',auth()->user()->teacher->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="divide-x">
                <td><a href="<?php echo e(route('teacher.module',['module'=>$module_id])); ?>"><?php echo e($resource->title); ?> <i class="icofont-external-link text-primary-500"></i></a></td>
                <td><?php echo e($resource->files->count()); ?></td>
                <td><?php echo e($resource->created_at->diffForHumans()); ?><i
                        onclick="confirm('Confirm deletion of module resource?') || event.stopImmediatePropagation()"
                        wire:click.prevent="removeResource(<?php echo e($resource->id); ?>)"
                        class="ml-5 text-red-600 cursor-pointer icofont-trash"></i></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3">No module resources found</td>
            </tr>
            <?php endif; ?>
            <?php else: ?>
            <tr>
                <td colspan="3">No module selected.</td>
            </tr>
            <?php endif; ?>

        </tbody>
    </table>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\J7 IT Solutions\elms\resources\views\livewire\teacher-courses-page.blade.php ENDPATH**/ ?>